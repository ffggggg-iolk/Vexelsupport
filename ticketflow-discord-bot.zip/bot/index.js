import {
  Client,
  GatewayIntentBits,
  Partials,
  Collection,
  Events,
  ActivityType
} from 'discord.js';
import dotenv from 'dotenv';
import * as setCommand from './commands/set.js';
import * as configCommand from './commands/config.js';
import { handleSelectMenu } from './interactions/selectMenus.js';
import { handleModalSubmit } from './interactions/modals.js';
import { handleButton } from './interactions/buttons.js';

dotenv.config();

const token = process.env.DISCORD_TOKEN;

if (!token || token === 'TU_TOKEN_DE_DISCORD_AQUI') {
  console.warn('⚠️ [AVISO] DISCORD_TOKEN no configurado.');
  console.warn('ℹ️ En Railway: Ve a la pestaña "Variables" de tu proyecto y agrega DISCORD_TOKEN y CLIENT_ID.');
  console.warn('ℹ️ En local: Agrega DISCORD_TOKEN en tu archivo .env.');
}

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.GuildMembers
  ],
  partials: [Partials.Channel, Partials.Message]
});

// Register slash commands into collection
client.commands = new Collection();
client.commands.set(setCommand.data.name, setCommand);
client.commands.set(configCommand.data.name, configCommand);

// Bot Ready event
client.once(Events.ClientReady, c => {
  console.log(`===============================================`);
  console.log(`🤖 ¡Bot iniciado con éxito como ${c.user.tag}!`);
  console.log(`🆔 Bot ID: ${c.user.id}`);
  console.log(`🌐 Servidores conectados: ${client.guilds.cache.size}`);
  console.log(`===============================================`);

  c.user.setPresence({
    activities: [{ name: 'Soporte con /config ticket-panel', type: ActivityType.Watching }],
    status: 'online'
  });
});

// Central interaction dispatcher
client.on(Events.InteractionCreate, async interaction => {
  try {
    // 1. Slash commands (/set, /config)
    if (interaction.isChatInputCommand()) {
      const command = client.commands.get(interaction.commandName);
      if (!command) {
        console.warn(`[WARN] Comando desconocido: ${interaction.commandName}`);
        return;
      }
      await command.execute(interaction);
      return;
    }

    // 2. Select Menus (ChannelSelect, RoleSelect, StringSelect)
    if (interaction.isAnySelectMenu()) {
      await handleSelectMenu(interaction);
      return;
    }

    // 3. Modal Submissions
    if (interaction.isModalSubmit()) {
      await handleModalSubmit(interaction);
      return;
    }

    // 4. Buttons (Config buttons, Ticket close, Confirmations)
    if (interaction.isButton()) {
      await handleButton(interaction);
      return;
    }
  } catch (error) {
    console.error('[INTERACTION_ERROR]', error);

    const errorMessage = {
      content: '❌ Ocurrió un error inesperado al procesar esta acción. Inténtalo de nuevo más tarde.',
      ephemeral: true
    };

    if (interaction.replied || interaction.deferred) {
      await interaction.followUp(errorMessage).catch(() => {});
    } else {
      await interaction.reply(errorMessage).catch(() => {});
    }
  }
});

// Handle uncaught exceptions gracefully
process.on('unhandledRejection', error => {
  console.error('[UNHANDLED_REJECTION]', error);
});

process.on('uncaughtException', error => {
  console.error('[UNCAUGHT_EXCEPTION]', error);
});

// Login only if valid token is provided
if (token && token !== 'TU_TOKEN_DE_DISCORD_AQUI') {
  client.login(token).catch(err => {
    console.error('❌ Error conectando a Discord:', err.message);
  });
} else {
  console.log('📌 Para conectar este bot a Discord:');
  console.log('1. Abre el archivo .env');
  console.log('2. Coloca tu DISCORD_TOKEN y CLIENT_ID');
  console.log('3. Ejecuta "npm run deploy:commands" para registrar los comandos');
  console.log('4. Ejecuta "npm run bot" para iniciar el bot');
}

export default client;
