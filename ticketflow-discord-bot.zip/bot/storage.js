import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const DATA_DIR = path.join(__dirname, 'data');
const DATA_FILE = path.join(DATA_DIR, 'guilds.json');

// Ensure data directory exists
if (!fs.existsSync(DATA_DIR)) {
  fs.mkdirSync(DATA_DIR, { recursive: true });
}

// Initial default configuration for a guild
const DEFAULT_CONFIG = {
  categoryId: null,         // Category where ticket channels are created
  panelChannelId: null,     // Text channel where panel is published
  staffRoleIds: [],         // Array of role IDs for support staff
  ticketCounter: 0,         // Sequential ticket counter
  panel: {
    title: '🎫 Sistema de Tickets de Soporte',
    description: '¡Bienvenido a nuestro centro de soporte!\n\nSi necesitas asistencia técnica, realizar consultas sobre compras o reportar algún inconveniente, selecciona una categoría en el menú desplegable a continuación.\n\nUn miembro de nuestro equipo de soporte te atenderá de inmediato.',
    imageUrl: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?q=80&w=1200&auto=format&fit=crop',
    color: '#5865F2',
    placeholder: 'Elige una categoría para abrir un ticket...',
    categories: [
      {
        id: 'soporte_general',
        label: 'Soporte General',
        description: 'Dudas, preguntas y ayuda general del servidor',
        emoji: '❓'
      },
      {
        id: 'compras_facturacion',
        label: 'Compras & Donaciones',
        description: 'Consultas sobre pagos, suscripciones y rangos',
        emoji: '💳'
      },
      {
        id: 'reportes_moderacion',
        label: 'Reportes & Moderación',
        description: 'Denuncias de usuarios, problemas o apelaciones',
        emoji: '🛡️'
      }
    ]
  },
  activeTickets: {} // channelId -> { userId, categoryId, createdAt }
};

/**
 * Reads all guilds data from disk
 */
function readAllData() {
  try {
    if (!fs.existsSync(DATA_FILE)) {
      fs.writeFileSync(DATA_FILE, JSON.stringify({}, null, 2), 'utf-8');
      return {};
    }
    const raw = fs.readFileSync(DATA_FILE, 'utf-8');
    return JSON.parse(raw);
  } catch (error) {
    console.error('[STORAGE] Error leyendo base de datos:', error);
    return {};
  }
}

/**
 * Writes all guilds data to disk safely
 */
function writeAllData(data) {
  try {
    const tempFile = `${DATA_FILE}.tmp`;
    fs.writeFileSync(tempFile, JSON.stringify(data, null, 2), 'utf-8');
    fs.renameSync(tempFile, DATA_FILE);
    return true;
  } catch (error) {
    console.error('[STORAGE] Error guardando base de datos:', error);
    return false;
  }
}

/**
 * Gets configuration for a specific guild, creating default if not exists
 */
export function getGuildConfig(guildId) {
  const allData = readAllData();
  if (!allData[guildId]) {
    allData[guildId] = JSON.parse(JSON.stringify(DEFAULT_CONFIG));
    writeAllData(allData);
  } else {
    // Ensure nested defaults exist
    allData[guildId] = {
      ...JSON.parse(JSON.stringify(DEFAULT_CONFIG)),
      ...allData[guildId],
      panel: {
        ...DEFAULT_CONFIG.panel,
        ...(allData[guildId].panel || {})
      }
    };
  }
  return allData[guildId];
}

/**
 * Updates partial configuration for a guild and persists
 */
export function updateGuildConfig(guildId, updates) {
  const allData = readAllData();
  const current = getGuildConfig(guildId);
  const updated = {
    ...current,
    ...updates,
    panel: {
      ...current.panel,
      ...(updates.panel || {})
    }
  };
  allData[guildId] = updated;
  writeAllData(allData);
  return updated;
}

/**
 * Increments and gets next ticket counter for guild
 */
export function incrementTicketCounter(guildId) {
  const config = getGuildConfig(guildId);
  config.ticketCounter = (config.ticketCounter || 0) + 1;
  updateGuildConfig(guildId, { ticketCounter: config.ticketCounter });
  return config.ticketCounter;
}

/**
 * Registers an active ticket
 */
export function saveActiveTicket(guildId, channelId, ticketData) {
  const config = getGuildConfig(guildId);
  config.activeTickets = config.activeTickets || {};
  config.activeTickets[channelId] = ticketData;
  updateGuildConfig(guildId, { activeTickets: config.activeTickets });
}

/**
 * Removes an active ticket
 */
export function removeActiveTicket(guildId, channelId) {
  const config = getGuildConfig(guildId);
  if (config.activeTickets && config.activeTickets[channelId]) {
    delete config.activeTickets[channelId];
    updateGuildConfig(guildId, { activeTickets: config.activeTickets });
  }
}
