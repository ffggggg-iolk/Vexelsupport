import { REST, Routes } from 'discord.js';
import dotenv from 'dotenv';
import { data as setData } from './commands/set.js';
import { data as configData } from './commands/config.js';

dotenv.config();

const token = process.env.DISCORD_TOKEN;
const clientId = process.env.CLIENT_ID;
const guildId = process.env.GUILD_ID;

if (!token || token === 'TU_TOKEN_DE_DISCORD_AQUI') {
  console.error('❌ Error: Falta configurar DISCORD_TOKEN. En Railway ve a la pestaña "Variables" y agrégalo allí.');
  process.exit(1);
}

if (!clientId || clientId === 'TU_CLIENT_ID_AQUI') {
  console.error('❌ Error: Falta configurar CLIENT_ID. En Railway ve a la pestaña "Variables" y agrégalo allí.');
  process.exit(1);
}

const commands = [
  setData.toJSON(),
  configData.toJSON()
];

const rest = new REST({ version: '10' }).setToken(token);

(async () => {
  try {
    console.log(`⏳ Iniciando registro de ${commands.length} comandos de aplicación (/set, /config)...`);

    if (guildId && guildId.trim() !== '') {
      // Guild-specific registration (instant updates for development/testing)
      console.log(`📌 Registrando comandos específicamente para el servidor: ${guildId}`);
      const data = await rest.put(
        Routes.applicationGuildCommands(clientId, guildId),
        { body: commands }
      );
      console.log(`✅ ¡Se registraron exitosamente ${data.length} comandos en el servidor ${guildId}!`);
    } else {
      // Global registration (takes ~1 hour to propagate across all Discord servers)
      console.log('🌐 Registrando comandos de forma global en Discord...');
      const data = await rest.put(
        Routes.applicationCommands(clientId),
        { body: commands }
      );
      console.log(`✅ ¡Se registraron exitosamente ${data.length} comandos globales en Discord!`);
    }
  } catch (error) {
    console.error('❌ Error registrando comandos en la API de Discord:', error);
    process.exit(1);
  }
})();
