import {
  ChannelType,
  PermissionFlagsBits,
  EmbedBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle
} from 'discord.js';
import {
  getGuildConfig,
  updateGuildConfig,
  incrementTicketCounter,
  saveActiveTicket
} from '../storage.js';
import {
  buildTicketWelcomeEmbed,
  buildConfigEmbed,
  buildConfigComponents
} from '../utils/embeds.js';

export async function handleSelectMenu(interaction) {
  const { customId, guild, user } = interaction;
  const config = getGuildConfig(guild.id);

  // 1. Selection for /set category-tickets
  if (customId === 'set_category_tickets_select') {
    const selectedCategoryId = interaction.values[0];
    const category = guild.channels.cache.get(selectedCategoryId);

    if (!category || category.type !== ChannelType.GuildCategory) {
      return interaction.reply({
        content: '❌ Por favor selecciona una categoría válida.',
        ephemeral: true
      });
    }

    updateGuildConfig(guild.id, { categoryId: selectedCategoryId });

    const confirmEmbed = new EmbedBuilder()
      .setColor(0x57F287)
      .setTitle('✅ Categoría de Tickets Configurada')
      .setDescription(`Los tickets de soporte se crearán automáticamente dentro de la categoría:\n📁 **${category.name}** \`(${category.id})\``)
      .setFooter({ text: 'Configuración guardada correctamente.' })
      .setTimestamp();

    return interaction.update({
      embeds: [confirmEmbed],
      components: []
    });
  }

  // 2. Selection for /set ticket-channel
  if (customId === 'set_ticket_channel_select') {
    const selectedChannelId = interaction.values[0];
    const channel = guild.channels.cache.get(selectedChannelId);

    if (!channel) {
      return interaction.reply({
        content: '❌ Por favor selecciona un canal válido.',
        ephemeral: true
      });
    }

    updateGuildConfig(guild.id, { panelChannelId: selectedChannelId });

    const confirmEmbed = new EmbedBuilder()
      .setColor(0x57F287)
      .setTitle('✅ Canal del Panel Configurado')
      .setDescription(
        `El canal de publicación del panel ha sido establecido a:\n💬 <#${channel.id}> \`(${channel.name})\`\n\n` +
        `💡 *Usa \`/config ticket-panel\` para personalizar los textos e imagen y pulsar "🚀 Publicar Panel de Tickets".*`
      )
      .setFooter({ text: 'Configuración guardada correctamente.' })
      .setTimestamp();

    return interaction.update({
      embeds: [confirmEmbed],
      components: []
    });
  }

  // 4. Selection for /set staff-roles
  if (customId === 'set_staff_roles_select') {
    const selectedRoleIds = interaction.values;
    
    updateGuildConfig(guild.id, { staffRoleIds: selectedRoleIds });

    const mentions = selectedRoleIds.map(id => `<@&${id}>`).join(', ');

    const confirmEmbed = new EmbedBuilder()
      .setColor(0x57F287)
      .setTitle('✅ Roles de Soporte Configurados')
      .setDescription(
        `Se han asignado **${selectedRoleIds.length} rol(es)** como equipo de atención:\n${mentions}\n\n` +
        `• Serán mencionados automáticamente al abrirse nuevos tickets.\n` +
        `• Tendrán acceso automático a los canales privados de tickets.`
      )
      .setFooter({ text: 'Configuración guardada correctamente.' })
      .setTimestamp();

    return interaction.update({
      embeds: [confirmEmbed],
      components: []
    });
  }

  // Delete Category select in /config ticket-panel
  if (customId === 'cfg_delete_category_select') {
    const catIdToDelete = interaction.values[0];
    const updatedCategories = (config.panel.categories || []).filter(c => c.id !== catIdToDelete);

    const updatedConfig = updateGuildConfig(guild.id, {
      panel: {
        ...config.panel,
        categories: updatedCategories
      }
    });

    const embed = buildConfigEmbed(updatedConfig, guild);
    const components = buildConfigComponents(updatedConfig);

    return interaction.update({
      embeds: [embed],
      components
    });
  }

  // User opened a ticket via the published panel's dropdown
  if (customId === 'ticket_select_category') {
    const selectedCatId = interaction.values[0];
    const categoryConfig = (config.panel.categories || []).find(c => c.id === selectedCatId);

    if (!categoryConfig) {
      return interaction.reply({
        content: '❌ No se encontró la categoría seleccionada. Contacta con un administrador.',
        ephemeral: true
      });
    }

    // Verify categoryId is configured
    if (!config.categoryId) {
      return interaction.reply({
        content: '⚠️ El sistema de tickets aún no tiene una categoría configurada por el administrador (`/set category-tickets`).',
        ephemeral: true
      });
    }

    const discordCategory = guild.channels.cache.get(config.categoryId);
    if (!discordCategory) {
      return interaction.reply({
        content: '⚠️ La categoría de Discord asignada ya no existe. El administrador debe reconfigurarla mediante `/set category-tickets`.',
        ephemeral: true
      });
    }

    // Check if user already has an open ticket for this category
    const active = config.activeTickets || {};
    const existingTicketChannelId = Object.keys(active).find(
      chId => active[chId].userId === user.id && guild.channels.cache.has(chId)
    );

    if (existingTicketChannelId) {
      return interaction.reply({
        content: `⚠️ Ya tienes un ticket abierto actualmente en <#${existingTicketChannelId}>. Por favor resuélvelo antes de abrir uno nuevo.`,
        ephemeral: true
      });
    }

    await interaction.deferReply({ ephemeral: true });

    try {
      const ticketNumber = incrementTicketCounter(guild.id);
      const cleanUsername = user.username.toLowerCase().replace(/[^a-z0-9_-]/g, '').slice(0, 15) || 'user';
      const channelName = `ticket-${cleanUsername}-${ticketNumber}`;

      // Build permission overwrites
      const permissionOverwrites = [
        // @everyone cannot see
        {
          id: guild.roles.everyone.id,
          deny: [PermissionFlagsBits.ViewChannel]
        },
        // Ticket author can see & send
        {
          id: user.id,
          allow: [
            PermissionFlagsBits.ViewChannel,
            PermissionFlagsBits.SendMessages,
            PermissionFlagsBits.ReadMessageHistory,
            PermissionFlagsBits.AttachFiles,
            PermissionFlagsBits.EmbedLinks
          ]
        },
        // Bot can manage
        {
          id: guild.members.me.id,
          allow: [
            PermissionFlagsBits.ViewChannel,
            PermissionFlagsBits.SendMessages,
            PermissionFlagsBits.ManageChannels,
            PermissionFlagsBits.ReadMessageHistory
          ]
        }
      ];

      // Add staff roles permissions
      if (Array.isArray(config.staffRoleIds)) {
        for (const roleId of config.staffRoleIds) {
          const role = guild.roles.cache.get(roleId);
          if (role) {
            permissionOverwrites.push({
              id: role.id,
              allow: [
                PermissionFlagsBits.ViewChannel,
                PermissionFlagsBits.SendMessages,
                PermissionFlagsBits.ReadMessageHistory,
                PermissionFlagsBits.AttachFiles,
                PermissionFlagsBits.EmbedLinks
              ]
            });
          }
        }
      }

      // Create private channel inside ticket category
      const ticketChannel = await guild.channels.create({
        name: channelName,
        type: ChannelType.GuildText,
        parent: config.categoryId,
        topic: `Ticket de soporte #${ticketNumber} | Usuario: ${user.tag || user.username} (${user.id}) | Categoría: ${categoryConfig.label}`,
        permissionOverwrites
      });

      // Save active ticket
      saveActiveTicket(guild.id, ticketChannel.id, {
        userId: user.id,
        categoryId: selectedCatId,
        ticketNumber,
        createdAt: Date.now()
      });

      // Prepare welcome embed & buttons inside the channel
      const { embed, buttonRow, staffMentions } = buildTicketWelcomeEmbed(user, categoryConfig, config);

      let content = null;
      if (staffMentions) {
        content = `🔔 ${staffMentions} — ¡Nuevo ticket abierto por <@${user.id}>!`;
      }

      await ticketChannel.send({
        content,
        embeds: [embed],
        components: [buttonRow]
      });

      // Respond to user
      return interaction.editReply({
        content: `✅ ¡Tu ticket ha sido creado exitosamente! Accede aquí: <#${ticketChannel.id}>`
      });
    } catch (err) {
      console.error('[TICKET_CREATE_ERROR]', err);
      return interaction.editReply({
        content: `❌ Ocurrió un error al crear tu canal de ticket. Verifica los permisos del bot (necesita "Administrar Canales" y "Administrar Roles").\nError: \`${err.message}\``
      });
    }
  }
}
