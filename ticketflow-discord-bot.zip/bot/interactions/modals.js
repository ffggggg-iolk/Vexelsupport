import { getGuildConfig, updateGuildConfig } from '../storage.js';
import { buildConfigEmbed, buildConfigComponents } from '../utils/embeds.js';

export async function handleModalSubmit(interaction) {
  const { customId, guild } = interaction;
  const config = getGuildConfig(guild.id);

  // 1. Edit Title and Message/Description
  if (customId === 'modal_cfg_text') {
    const title = interaction.fields.getTextInputValue('input_title').trim();
    const description = interaction.fields.getTextInputValue('input_description').trim();

    const updatedConfig = updateGuildConfig(guild.id, {
      panel: {
        ...config.panel,
        title: title || config.panel.title,
        description: description || config.panel.description
      }
    });

    const embed = buildConfigEmbed(updatedConfig, guild);
    const components = buildConfigComponents(updatedConfig);

    return interaction.update({
      embeds: [embed],
      components
    });
  }

  // 2. Edit Image / Banner
  if (customId === 'modal_cfg_image') {
    let imageUrl = interaction.fields.getTextInputValue('input_image_url').trim();
    
    // Allow removing image by writing "quitar", "none", or leaving empty
    if (!imageUrl || imageUrl.toLowerCase() === 'quitar' || imageUrl.toLowerCase() === 'none') {
      imageUrl = null;
    }

    const updatedConfig = updateGuildConfig(guild.id, {
      panel: {
        ...config.panel,
        imageUrl
      }
    });

    const embed = buildConfigEmbed(updatedConfig, guild);
    const components = buildConfigComponents(updatedConfig);

    return interaction.update({
      embeds: [embed],
      components
    });
  }

  // 3. Edit Embed Color
  if (customId === 'modal_cfg_color') {
    let color = interaction.fields.getTextInputValue('input_color').trim();
    if (!color.startsWith('#')) {
      color = `#${color}`;
    }

    // Validate hex
    if (!/^#[0-9A-Fa-f]{6}$/.test(color)) {
      color = '#5865F2';
    }

    const updatedConfig = updateGuildConfig(guild.id, {
      panel: {
        ...config.panel,
        color
      }
    });

    const embed = buildConfigEmbed(updatedConfig, guild);
    const components = buildConfigComponents(updatedConfig);

    return interaction.update({
      embeds: [embed],
      components
    });
  }

  // 4. Add new ticket category
  if (customId === 'modal_cfg_add_cat') {
    const rawLabel = interaction.fields.getTextInputValue('input_cat_label').trim();
    const rawEmoji = interaction.fields.getTextInputValue('input_cat_emoji').trim();
    const rawDesc = interaction.fields.getTextInputValue('input_cat_desc').trim();
    let rawId = interaction.fields.getTextInputValue('input_cat_id')?.trim();

    if (!rawId) {
      rawId = rawLabel.toLowerCase().replace(/[^a-z0-9_-]/g, '_').slice(0, 30);
    }

    const newCategory = {
      id: rawId,
      label: rawLabel.slice(0, 100),
      emoji: rawEmoji || '🎫',
      description: rawDesc.slice(0, 100)
    };

    const currentCats = [...(config.panel.categories || [])];
    
    // Check if ID already exists, replace or append
    const existingIndex = currentCats.findIndex(c => c.id === newCategory.id);
    if (existingIndex >= 0) {
      currentCats[existingIndex] = newCategory;
    } else {
      currentCats.push(newCategory);
    }

    const updatedConfig = updateGuildConfig(guild.id, {
      panel: {
        ...config.panel,
        categories: currentCats
      }
    });

    const embed = buildConfigEmbed(updatedConfig, guild);
    const components = buildConfigComponents(updatedConfig);

    return interaction.update({
      embeds: [embed],
      components
    });
  }
}
