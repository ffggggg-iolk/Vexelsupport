import {
  ModalBuilder,
  TextInputBuilder,
  TextInputStyle,
  ActionRowBuilder,
  EmbedBuilder,
  StringSelectMenuBuilder,
  StringSelectMenuOptionBuilder,
  ButtonStyle,
  ButtonBuilder
} from 'discord.js';
import { getGuildConfig, removeActiveTicket } from '../storage.js';
import {
  buildConfigEmbed,
  buildConfigComponents,
  buildPublishedPanelEmbed,
  buildTicketSelectMenu,
  buildCloseConfirmationRow
} from '../utils/embeds.js';

export async function handleButton(interaction) {
  const { customId, guild, channel, user } = interaction;
  const config = getGuildConfig(guild.id);

  // 1. Edit Title and Message Modal
  if (customId === 'btn_cfg_text') {
    const modal = new ModalBuilder()
      .setCustomId('modal_cfg_text')
      .setTitle('Editar Título y Mensaje del Panel');

    const titleInput = new TextInputBuilder()
      .setCustomId('input_title')
      .setLabel('Título del Panel')
      .setStyle(TextInputStyle.Short)
      .setValue(config.panel.title || '')
      .setMaxLength(250)
      .setRequired(true);

    const descInput = new TextInputBuilder()
      .setCustomId('input_description')
      .setLabel('Mensaje / Descripción del Panel')
      .setStyle(TextInputStyle.Paragraph)
      .setValue(config.panel.description || '')
      .setMaxLength(2000)
      .setRequired(true);

    modal.addComponents(
      new ActionRowBuilder().addComponents(titleInput),
      new ActionRowBuilder().addComponents(descInput)
    );

    return interaction.showModal(modal);
  }

  // 2. Edit Image / Banner Modal
  if (customId === 'btn_cfg_image') {
    const modal = new ModalBuilder()
      .setCustomId('modal_cfg_image')
      .setTitle('Configurar Imagen o Banner');

    const imgInput = new TextInputBuilder()
      .setCustomId('input_image_url')
      .setLabel('URL de Imagen (o escribe "quitar" para borrar)')
      .setPlaceholder('https://ejemplo.com/banner.png')
      .setStyle(TextInputStyle.Short)
      .setValue(config.panel.imageUrl || '')
      .setRequired(false);

    modal.addComponents(new ActionRowBuilder().addComponents(imgInput));
    return interaction.showModal(modal);
  }

  // 3. Edit Embed Color Modal
  if (customId === 'btn_cfg_color') {
    const modal = new ModalBuilder()
      .setCustomId('modal_cfg_color')
      .setTitle('Color del Embed (Hexadecimal)');

    const colorInput = new TextInputBuilder()
      .setCustomId('input_color')
      .setLabel('Código Hex (#5865F2, #57F287, #ED4245, etc.)')
      .setStyle(TextInputStyle.Short)
      .setValue(config.panel.color || '#5865F2')
      .setMaxLength(7)
      .setRequired(true);

    modal.addComponents(new ActionRowBuilder().addComponents(colorInput));
    return interaction.showModal(modal);
  }

  // 4. Add Category Modal
  if (customId === 'btn_cfg_add_cat') {
    const modal = new ModalBuilder()
      .setCustomId('modal_cfg_add_cat')
      .setTitle('Añadir Categoría de Ticket');

    const labelInput = new TextInputBuilder()
      .setCustomId('input_cat_label')
      .setLabel('Nombre de la Categoría')
      .setPlaceholder('Ej: Soporte Técnico, Compras, Apelación')
      .setStyle(TextInputStyle.Short)
      .setMaxLength(80)
      .setRequired(true);

    const emojiInput = new TextInputBuilder()
      .setCustomId('input_cat_emoji')
      .setLabel('Emoji (Unicode o nombre)')
      .setPlaceholder('Ej: 🔧, 🛒, 🛡️, ❓')
      .setStyle(TextInputStyle.Short)
      .setMaxLength(10)
      .setRequired(false);

    const descInput = new TextInputBuilder()
      .setCustomId('input_cat_desc')
      .setLabel('Descripción breve (subtítulo)')
      .setPlaceholder('Ej: Ayuda con errores del juego o problemas de conexión')
      .setStyle(TextInputStyle.Short)
      .setMaxLength(100)
      .setRequired(false);

    const idInput = new TextInputBuilder()
      .setCustomId('input_cat_id')
      .setLabel('Identificador interno (opcional)')
      .setPlaceholder('Ej: tech_support')
      .setStyle(TextInputStyle.Short)
      .setMaxLength(30)
      .setRequired(false);

    modal.addComponents(
      new ActionRowBuilder().addComponents(labelInput),
      new ActionRowBuilder().addComponents(emojiInput),
      new ActionRowBuilder().addComponents(descInput),
      new ActionRowBuilder().addComponents(idInput)
    );

    return interaction.showModal(modal);
  }

  // 5. Delete Category Selection
  if (customId === 'btn_cfg_del_cat') {
    const categories = config.panel.categories || [];
    if (categories.length === 0) {
      return interaction.reply({
        content: '⚠️ No hay categorías para eliminar.',
        ephemeral: true
      });
    }

    const selectOptions = categories.map(cat =>
      new StringSelectMenuOptionBuilder()
        .setLabel(cat.label)
        .setValue(cat.id)
        .setDescription((cat.description || '').slice(0, 50))
        .setEmoji(cat.emoji || '🎫')
    );

    const selectMenu = new StringSelectMenuBuilder()
      .setCustomId('cfg_delete_category_select')
      .setPlaceholder('Selecciona la categoría que deseas eliminar...')
      .addOptions(selectOptions);

    const row = new ActionRowBuilder().addComponents(selectMenu);

    return interaction.reply({
      content: '🗑️ Elige en el menú la categoría que deseas remover:',
      components: [row],
      ephemeral: true
    });
  }

  // 6. Refresh Config Embed
  if (customId === 'btn_cfg_refresh') {
    const embed = buildConfigEmbed(config, guild);
    const components = buildConfigComponents(config);

    return interaction.update({
      embeds: [embed],
      components
    });
  }

  // 7. Publish Panel to configured channel
  if (customId === 'btn_cfg_publish') {
    if (!config.panelChannelId) {
      return interaction.reply({
        content: '❌ No has configurado el canal de tickets. Primero usa el comando `/set ticket-channel`.',
        ephemeral: true
      });
    }

    if (!config.categoryId) {
      return interaction.reply({
        content: '⚠️ Advertencia: No has configurado la categoría de tickets (`/set category-tickets`). Te recomendamos configurarla antes para que los tickets se organicen en su propia categoría.',
        ephemeral: true
      });
    }

    const targetChannel = guild.channels.cache.get(config.panelChannelId);
    if (!targetChannel) {
      return interaction.reply({
        content: `❌ El canal configurado (\`${config.panelChannelId}\`) ya no existe en el servidor. Configura uno nuevo con \`/set ticket-channel\`.`,
        ephemeral: true
      });
    }

    try {
      const panelEmbed = buildPublishedPanelEmbed(config, guild);
      const panelComponents = buildTicketSelectMenu(config);

      await targetChannel.send({
        embeds: [panelEmbed],
        components: [panelComponents]
      });

      return interaction.reply({
        content: `🎉 **¡Panel de tickets publicado con éxito en <#${targetChannel.id}>!**\nLos usuarios ya pueden seleccionar una categoría del menú para abrir tickets.`,
        ephemeral: true
      });
    } catch (err) {
      console.error('[PUBLISH_PANEL_ERROR]', err);
      return interaction.reply({
        content: `❌ Error al enviar el panel al canal <#${targetChannel.id}>: \`${err.message}\`. Verifica que el bot tenga permisos de "Enviar Mensajes" e "Insertar Enlaces" en ese canal.`,
        ephemeral: true
      });
    }
  }

  // 8. Close ticket requested inside ticket channel
  if (customId === 'ticket_btn_close') {
    const confirmRow = buildCloseConfirmationRow();
    return interaction.reply({
      content: `⚠️ **¿Estás seguro de que deseas cerrar este ticket?**\nEl canal será eliminado permanentemente tras la confirmación.`,
      components: [confirmRow]
    });
  }

  // 9. Confirm close ticket
  if (customId === 'ticket_btn_confirm_close') {
    await interaction.update({
      content: `🔒 **Ticket cerrado por <@${user.id}>.**\nEste canal será eliminado en **5 segundos**...`,
      components: []
    });

    // Remove active ticket record
    removeActiveTicket(guild.id, channel.id);

    setTimeout(async () => {
      try {
        if (channel && channel.deletable) {
          await channel.delete(`Ticket cerrado por ${user.tag || user.username}`);
        }
      } catch (err) {
        console.error('[DELETE_CHANNEL_ERROR]', err);
      }
    }, 5000);

    return;
  }

  // 10. Cancel close ticket
  if (customId === 'ticket_btn_cancel_close') {
    return interaction.update({
      content: '✅ Cierre de ticket cancelado. El canal permanece abierto.',
      components: []
    });
  }
}
