import {
  EmbedBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  StringSelectMenuBuilder,
  StringSelectMenuOptionBuilder
} from 'discord.js';

/**
 * Parses hex color safely
 */
export function resolveHexColor(color) {
  if (!color) return 0x5865F2;
  const clean = color.replace('#', '');
  const parsed = parseInt(clean, 16);
  return isNaN(parsed) ? 0x5865F2 : parsed;
}

/**
 * Builds the interactive configuration embed for /config ticket-panel
 */
export function buildConfigEmbed(config, guild) {
  const categoryChannel = config.categoryId ? guild.channels.cache.get(config.categoryId) : null;
  const panelChannel = config.panelChannelId ? guild.channels.cache.get(config.panelChannelId) : null;
  
  const staffRoleList = (config.staffRoleIds || []).length > 0
    ? config.staffRoleIds.map(id => `<@&${id}>`).join(', ')
    : '*Ninguno configurado (usa `/set staff-roles`)*';

  const categoriesFormatted = (config.panel.categories || []).length > 0
    ? config.panel.categories.map((c, i) => `${i + 1}. ${c.emoji ? `${c.emoji} ` : ''}**${c.label}** - *${c.description || 'Sin descripción'}* \`(${c.id})\``).join('\n')
    : '*No hay categorías configuradas. Añade una con el botón inferior.*';

  const embed = new EmbedBuilder()
    .setColor(resolveHexColor(config.panel.color))
    .setTitle('⚙️ Panel de Configuración de Tickets')
    .setDescription(
      'Configura visualmente todos los aspectos de tu sistema de tickets. ' +
      'Utiliza los botones interactivos a continuación para modificar textos, imagen, colores, categorías y publicar el panel.'
    )
    .addFields(
      {
        name: '📌 Estado de Canales y Roles',
        value: 
          `• **Categoría de Tickets:** ${categoryChannel ? `📁 \`${categoryChannel.name}\`` : '❌ *No establecida (`/set category-tickets`)*'}\n` +
          `• **Canal del Panel:** ${panelChannel ? `💬 <#${panelChannel.id}>` : '❌ *No establecido (`/set ticket-channel`)*'}\n` +
          `• **Roles de Soporte:** ${staffRoleList}`,
        inline: false
      },
      {
        name: '📝 Vista Previa: Título del Panel',
        value: `\`\`\`${config.panel.title}\`\`\``,
        inline: false
      },
      {
        name: '📄 Vista Previa: Mensaje / Descripción',
        value: `${config.panel.description.slice(0, 500)}${config.panel.description.length > 500 ? '...' : ''}`,
        inline: false
      },
      {
        name: `🏷️ Categorías Disponibles (${(config.panel.categories || []).length}/25)`,
        value: categoriesFormatted,
        inline: false
      },
      {
        name: '🎨 Color & Imagen',
        value: `• **Color Hex:** \`${config.panel.color || '#5865F2'}\`\n• **Imagen/Banner:** ${config.panel.imageUrl ? `[Ver Imagen](${config.panel.imageUrl})` : '*Sin imagen*'}`,
        inline: false
      }
    )
    .setFooter({ text: 'Los cambios se guardan automáticamente en disco.' })
    .setTimestamp();

  if (config.panel.imageUrl) {
    embed.setImage(config.panel.imageUrl);
  }

  return embed;
}

/**
 * Builds the button components for the configuration panel
 */
export function buildConfigComponents(config) {
  // Row 1: Content editing buttons
  const row1 = new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId('btn_cfg_text')
      .setLabel('Editar Título y Texto')
      .setEmoji('📝')
      .setStyle(ButtonStyle.Primary),
    new ButtonBuilder()
      .setCustomId('btn_cfg_image')
      .setLabel('Imagen / Banner')
      .setEmoji('🖼️')
      .setStyle(ButtonStyle.Secondary),
    new ButtonBuilder()
      .setCustomId('btn_cfg_color')
      .setLabel('Color Embed')
      .setEmoji('🎨')
      .setStyle(ButtonStyle.Secondary),
    new ButtonBuilder()
      .setCustomId('btn_cfg_add_cat')
      .setLabel('Añadir Categoría')
      .setEmoji('➕')
      .setStyle(ButtonStyle.Secondary)
  );

  // Row 2: Management & Publishing buttons
  const row2 = new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId('btn_cfg_del_cat')
      .setLabel('Eliminar Categoría')
      .setEmoji('🗑️')
      .setStyle(ButtonStyle.Danger)
      .setDisabled(!config.panel.categories || config.panel.categories.length === 0),
    new ButtonBuilder()
      .setCustomId('btn_cfg_publish')
      .setLabel('Publicar Panel de Tickets')
      .setEmoji('🚀')
      .setStyle(ButtonStyle.Success),
    new ButtonBuilder()
      .setCustomId('btn_cfg_refresh')
      .setLabel('Refrescar')
      .setEmoji('🔄')
      .setStyle(ButtonStyle.Secondary)
  );

  return [row1, row2];
}

/**
 * Builds the public ticket panel embed that users interact with
 */
export function buildPublishedPanelEmbed(config, guild) {
  const embed = new EmbedBuilder()
    .setColor(resolveHexColor(config.panel.color))
    .setTitle(config.panel.title || '🎫 Sistema de Tickets de Soporte')
    .setDescription(config.panel.description || 'Selecciona una categoría a continuación para iniciar tu ticket.')
    .setFooter({
      text: `${guild.name} • Sistema de Atención y Soporte`,
      iconURL: guild.iconURL({ dynamic: true }) || undefined
    })
    .setTimestamp();

  if (config.panel.imageUrl) {
    embed.setImage(config.panel.imageUrl);
  }

  return embed;
}

/**
 * Builds the StringSelectMenu for users to choose a ticket category
 */
export function buildTicketSelectMenu(config) {
  const categories = config.panel.categories || [];
  
  if (categories.length === 0) {
    // Fallback option if no categories yet
    const selectMenu = new StringSelectMenuBuilder()
      .setCustomId('ticket_select_category')
      .setPlaceholder('No hay categorías disponibles')
      .setDisabled(true)
      .addOptions([
        new StringSelectMenuOptionBuilder()
          .setLabel('Sin categorías')
          .setValue('none')
      ]);
    return new ActionRowBuilder().addComponents(selectMenu);
  }

  const options = categories.map(cat => {
    const opt = new StringSelectMenuOptionBuilder()
      .setLabel(cat.label.slice(0, 100))
      .setValue(cat.id.slice(0, 100))
      .setDescription((cat.description || '').slice(0, 100));

    if (cat.emoji) {
      opt.setEmoji(cat.emoji);
    }
    return opt;
  });

  const selectMenu = new StringSelectMenuBuilder()
    .setCustomId('ticket_select_category')
    .setPlaceholder(config.panel.placeholder || 'Selecciona el motivo de tu ticket...')
    .addOptions(options);

  return new ActionRowBuilder().addComponents(selectMenu);
}

/**
 * Builds the welcome embed inside a newly created ticket channel
 */
export function buildTicketWelcomeEmbed(user, category, config) {
  const staffMentions = (config.staffRoleIds || []).length > 0
    ? config.staffRoleIds.map(id => `<@&${id}>`).join(' ')
    : null;

  const embed = new EmbedBuilder()
    .setColor(resolveHexColor(config.panel.color))
    .setTitle(`🎫 Ticket de Soporte #${config.ticketCounter}`)
    .setDescription(
      `Hola <@${user.id}>, gracias por comunicarte con nosotros.\n\n` +
      `**Categoría:** ${category.emoji ? `${category.emoji} ` : ''}**${category.label}**\n` +
      `**Detalles:** ${category.description || 'Atención personalizada'}\n\n` +
      `Explica tu consulta detalladamente. El equipo de soporte ha sido notificado y te atenderá pronto.`
    )
    .addFields(
      { name: '👤 Solicitante', value: `<@${user.id}> (${user.tag || user.username})`, inline: true },
      { name: '🕒 Creado', value: `<t:${Math.floor(Date.now() / 1000)}:R>`, inline: true },
      { name: '🔒 Acceso Privado', value: 'Solo tú y el equipo de soporte pueden ver este canal.', inline: false }
    )
    .setFooter({ text: 'Haz clic en el botón inferior para cerrar el ticket cuando tu duda esté resuelta.' })
    .setTimestamp();

  const buttonRow = new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId('ticket_btn_close')
      .setLabel('Cerrar Ticket')
      .setEmoji('🔒')
      .setStyle(ButtonStyle.Danger)
  );

  return { embed, buttonRow, staffMentions };
}

/**
 * Builds the close ticket confirmation component
 */
export function buildCloseConfirmationRow() {
  return new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId('ticket_btn_confirm_close')
      .setLabel('Confirmar Cierre')
      .setEmoji('✅')
      .setStyle(ButtonStyle.Danger),
    new ButtonBuilder()
      .setCustomId('ticket_btn_cancel_close')
      .setLabel('Cancelar')
      .setEmoji('❌')
      .setStyle(ButtonStyle.Secondary)
  );
}
