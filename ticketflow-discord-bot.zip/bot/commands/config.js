import {
  SlashCommandBuilder,
  PermissionFlagsBits
} from 'discord.js';
import { getGuildConfig } from '../storage.js';
import { buildConfigEmbed, buildConfigComponents } from '../utils/embeds.js';

export const data = new SlashCommandBuilder()
  .setName('config')
  .setDescription('Configura y personaliza visualmente el sistema de tickets')
  .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild)
  .setDMPermission(false)
  // 3. /config ticket-panel
  .addSubcommand(subcommand =>
    subcommand
      .setName('ticket-panel')
      .setDescription('Abre la interfaz visual para personalizar el panel de tickets (título, mensaje, imagen, categorías)')
  );

export async function execute(interaction) {
  if (!interaction.memberPermissions.has(PermissionFlagsBits.ManageGuild)) {
    return interaction.reply({
      content: '❌ No tienes permisos suficientes (`Gestionar Servidor`) para ejecutar este comando.',
      ephemeral: true
    });
  }

  const subcommand = interaction.options.getSubcommand();

  if (subcommand === 'ticket-panel') {
    const config = getGuildConfig(interaction.guildId);
    const embed = buildConfigEmbed(config, interaction.guild);
    const components = buildConfigComponents(config);

    return interaction.reply({
      embeds: [embed],
      components,
      ephemeral: true
    });
  }
}
