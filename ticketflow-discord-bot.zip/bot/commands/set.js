import {
  SlashCommandBuilder,
  PermissionFlagsBits,
  ChannelType,
  ChannelSelectMenuBuilder,
  RoleSelectMenuBuilder,
  ActionRowBuilder,
  EmbedBuilder
} from 'discord.js';

export const data = new SlashCommandBuilder()
  .setName('set')
  .setDescription('Configura los parámetros principales del sistema de tickets')
  .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild)
  .setDMPermission(false)
  // 1. /set category-tickets
  .addSubcommand(subcommand =>
    subcommand
      .setName('category-tickets')
      .setDescription('Selecciona la categoría donde se crearán todos los canales de tickets')
  )
  // 2. /set ticket-channel
  .addSubcommand(subcommand =>
    subcommand
      .setName('ticket-channel')
      .setDescription('Selecciona el canal de texto donde se publicará el panel de tickets')
  )
  // 4. /set staff-roles
  .addSubcommand(subcommand =>
    subcommand
      .setName('staff-roles')
      .setDescription('Selecciona los roles de soporte que tendrán acceso y menciones en los tickets')
  );

export async function execute(interaction) {
  // Check permission
  if (!interaction.memberPermissions.has(PermissionFlagsBits.ManageGuild)) {
    return interaction.reply({
      content: '❌ No tienes permisos suficientes (`Gestionar Servidor`) para ejecutar este comando.',
      ephemeral: true
    });
  }

  const subcommand = interaction.options.getSubcommand();

  // 1. /set category-tickets
  if (subcommand === 'category-tickets') {
    const channelSelect = new ChannelSelectMenuBuilder()
      .setCustomId('set_category_tickets_select')
      .setPlaceholder('📁 Elige la categoría de Discord para los tickets...')
      .setChannelTypes(ChannelType.GuildCategory);

    const row = new ActionRowBuilder().addComponents(channelSelect);

    const embed = new EmbedBuilder()
      .setColor(0x5865F2)
      .setTitle('📁 Configurar Categoría de Tickets')
      .setDescription(
        'Selecciona mediante el menú desplegable inferior la **categoría** en la que el bot creará automáticamente los canales privados de cada ticket.'
      )
      .setFooter({ text: 'Solo se muestran categorías del servidor.' });

    return interaction.reply({
      embeds: [embed],
      components: [row],
      ephemeral: true
    });
  }

  // 2. /set ticket-channel
  if (subcommand === 'ticket-channel') {
    const channelSelect = new ChannelSelectMenuBuilder()
      .setCustomId('set_ticket_channel_select')
      .setPlaceholder('💬 Elige el canal donde publicar el panel...')
      .setChannelTypes(ChannelType.GuildText, ChannelType.GuildAnnouncement);

    const row = new ActionRowBuilder().addComponents(channelSelect);

    const embed = new EmbedBuilder()
      .setColor(0x5865F2)
      .setTitle('💬 Configurar Canal del Panel')
      .setDescription(
        'Selecciona mediante el menú desplegable el **canal de texto** donde se enviará el panel de tickets interactivo para los usuarios.'
      )
      .setFooter({ text: 'Solo se muestran canales de texto y anuncios.' });

    return interaction.reply({
      embeds: [embed],
      components: [row],
      ephemeral: true
    });
  }

  // 4. /set staff-roles
  if (subcommand === 'staff-roles') {
    const roleSelect = new RoleSelectMenuBuilder()
      .setCustomId('set_staff_roles_select')
      .setPlaceholder('🛡️ Selecciona los roles de soporte (uno o varios)...')
      .setMinValues(1)
      .setMaxValues(20);

    const row = new ActionRowBuilder().addComponents(roleSelect);

    const embed = new EmbedBuilder()
      .setColor(0x5865F2)
      .setTitle('🛡️ Configurar Roles de Soporte')
      .setDescription(
        'Selecciona uno o más **roles del servidor** que actuarán como personal de soporte.\n\n' +
        '• **Notificaciones:** El bot mencionará automáticamente a estos roles cuando se abra un nuevo ticket.\n' +
        '• **Permisos:** Estos roles tendrán acceso visual y de escritura exclusivo a los canales de tickets.'
      )
      .setFooter({ text: 'Puedes seleccionar múltiples roles a la vez.' });

    return interaction.reply({
      embeds: [embed],
      components: [row],
      ephemeral: true
    });
  }
}
