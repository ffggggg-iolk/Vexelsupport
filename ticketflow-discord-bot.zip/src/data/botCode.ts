export interface BotFile {
  name: string;
  path: string;
  language: string;
  description: string;
  content: string;
}

export const BOT_FILES: BotFile[] = [
  {
    name: 'index.js',
    path: 'bot/index.js',
    language: 'javascript',
    description: 'Punto de entrada principal del bot, inicialización de discord.js v14 y enrutador central de interacciones.',
    content: `import {
  Client,
  GatewayIntentBits,
  Partials,
  Collection,
  Events,
  ActivityType
} from 'discord.js';
import dotenv from 'dotenv';
import * as setCommand from './commands/set.js';
import * as configCommand from './commands/config.js';
import { handleSelectMenu } from './interactions/selectMenus.js';
import { handleModalSubmit } from './interactions/modals.js';
import { handleButton } from './interactions/buttons.js';

dotenv.config();

const token = process.env.DISCORD_TOKEN;

if (!token || token === 'TU_TOKEN_DE_DISCORD_AQUI') {
  console.warn('⚠️ [AVISO] DISCORD_TOKEN no configurado en .env.');
}

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.GuildMembers
  ],
  partials: [Partials.Channel, Partials.Message]
});

// Registrar comandos slash en la colección del cliente
client.commands = new Collection();
client.commands.set(setCommand.data.name, setCommand);
client.commands.set(configCommand.data.name, configCommand);

// Evento Ready al conectar
client.once(Events.ClientReady, c => {
  console.log('===============================================');
  console.log(\`🤖 ¡Bot iniciado con éxito como \${c.user.tag}!\`);
  console.log(\`🆔 Bot ID: \${c.user.id}\`);
  console.log(\`🌐 Servidores conectados: \${client.guilds.cache.size}\`);
  console.log('===============================================');

  c.user.setPresence({
    activities: [{ name: 'Soporte con /config ticket-panel', type: ActivityType.Watching }],
    status: 'online'
  });
});

// Enrutador central de interacciones
client.on(Events.InteractionCreate, async interaction => {
  try {
    // 1. Comandos Slash (/set, /config)
    if (interaction.isChatInputCommand()) {
      const command = client.commands.get(interaction.commandName);
      if (!command) return;
      await command.execute(interaction);
      return;
    }

    // 2. Select Menus (ChannelSelect, RoleSelect, StringSelect)
    if (interaction.isAnySelectMenu()) {
      await handleSelectMenu(interaction);
      return;
    }

    // 3. Modales de Discord
    if (interaction.isModalSubmit()) {
      await handleModalSubmit(interaction);
      return;
    }

    // 4. Botones interactivos
    if (interaction.isButton()) {
      await handleButton(interaction);
      return;
    }
  } catch (error) {
    console.error('[INTERACTION_ERROR]', error);
    const errorMessage = {
      content: '❌ Ocurrió un error al procesar esta acción.',
      ephemeral: true
    };
    if (interaction.replied || interaction.deferred) {
      await interaction.followUp(errorMessage).catch(() => {});
    } else {
      await interaction.reply(errorMessage).catch(() => {});
    }
  }
});

// Iniciar sesión en Discord
if (token && token !== 'TU_TOKEN_DE_DISCORD_AQUI') {
  client.login(token).catch(err => console.error('Error conectando a Discord:', err.message));
}

export default client;`
  },
  {
    name: 'set.js',
    path: 'bot/commands/set.js',
    language: 'javascript',
    description: 'Implementa /set con los subcomandos category-tickets, ticket-channel y staff-roles con menús nativos.',
    content: `import {
  SlashCommandBuilder,
  PermissionFlagsBits,
  ChannelType,
  ChannelSelectMenuBuilder,
  RoleSelectMenuBuilder,
  ActionRowBuilder,
  EmbedBuilder
} from 'discord.js';

export const data = new SlashCommandBuilder()
  .setName('set')
  .setDescription('Configura los parámetros principales del sistema de tickets')
  .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild)
  .setDMPermission(false)
  // 1. /set category-tickets
  .addSubcommand(sub =>
    sub.setName('category-tickets')
      .setDescription('Selecciona la categoría donde se crearán todos los canales de tickets')
  )
  // 2. /set ticket-channel
  .addSubcommand(sub =>
    sub.setName('ticket-channel')
      .setDescription('Selecciona el canal de texto donde se publicará el panel de tickets')
  )
  // 4. /set staff-roles
  .addSubcommand(sub =>
    sub.setName('staff-roles')
      .setDescription('Selecciona los roles de soporte que tendrán acceso y menciones en los tickets')
  );

export async function execute(interaction) {
  if (!interaction.memberPermissions.has(PermissionFlagsBits.ManageGuild)) {
    return interaction.reply({
      content: '❌ No tienes permisos de \`Gestionar Servidor\` para usar este comando.',
      ephemeral: true
    });
  }

  const subcommand = interaction.options.getSubcommand();

  // 1. /set category-tickets
  if (subcommand === 'category-tickets') {
    const channelSelect = new ChannelSelectMenuBuilder()
      .setCustomId('set_category_tickets_select')
      .setPlaceholder('📁 Elige la categoría de Discord para los tickets...')
      .setChannelTypes(ChannelType.GuildCategory);

    const row = new ActionRowBuilder().addComponents(channelSelect);

    const embed = new EmbedBuilder()
      .setColor(0x5865F2)
      .setTitle('📁 Configurar Categoría de Tickets')
      .setDescription('Selecciona mediante el menú desplegable la **categoría** donde se crearán los tickets.')
      .setFooter({ text: 'Solo se muestran categorías del servidor.' });

    return interaction.reply({ embeds: [embed], components: [row], ephemeral: true });
  }

  // 2. /set ticket-channel
  if (subcommand === 'ticket-channel') {
    const channelSelect = new ChannelSelectMenuBuilder()
      .setCustomId('set_ticket_channel_select')
      .setPlaceholder('💬 Elige el canal donde publicar el panel...')
      .setChannelTypes(ChannelType.GuildText, ChannelType.GuildAnnouncement);

    const row = new ActionRowBuilder().addComponents(channelSelect);

    const embed = new EmbedBuilder()
      .setColor(0x5865F2)
      .setTitle('💬 Configurar Canal del Panel')
      .setDescription('Selecciona el **canal de texto** donde se enviará el panel de tickets.')
      .setFooter({ text: 'Solo se muestran canales de texto y anuncios.' });

    return interaction.reply({ embeds: [embed], components: [row], ephemeral: true });
  }

  // 4. /set staff-roles
  if (subcommand === 'staff-roles') {
    const roleSelect = new RoleSelectMenuBuilder()
      .setCustomId('set_staff_roles_select')
      .setPlaceholder('🛡️ Selecciona los roles de soporte...')
      .setMinValues(1)
      .setMaxValues(20);

    const row = new ActionRowBuilder().addComponents(roleSelect);

    const embed = new EmbedBuilder()
      .setColor(0x5865F2)
      .setTitle('🛡️ Configurar Roles de Soporte')
      .setDescription(
        'Selecciona uno o más **roles del servidor** que actuarán como personal de soporte.\\n\\n' +
        '• El bot mencionará automáticamente a estos roles al abrir un ticket.\\n' +
        '• Tendrán acceso automático a los canales privados creados.'
      );

    return interaction.reply({ embeds: [embed], components: [row], ephemeral: true });
  }
}`
  },
  {
    name: 'config.js',
    path: 'bot/commands/config.js',
    language: 'javascript',
    description: 'Implementa /config ticket-panel abriendo el panel interactivo visual con botones y modales.',
    content: `import { SlashCommandBuilder, PermissionFlagsBits } from 'discord.js';
import { getGuildConfig } from '../storage.js';
import { buildConfigEmbed, buildConfigComponents } from '../utils/embeds.js';

export const data = new SlashCommandBuilder()
  .setName('config')
  .setDescription('Configura y personaliza visualmente el sistema de tickets')
  .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild)
  .setDMPermission(false)
  // 3. /config ticket-panel
  .addSubcommand(sub =>
    sub.setName('ticket-panel')
      .setDescription('Abre la interfaz visual para personalizar el panel de tickets')
  );

export async function execute(interaction) {
  if (!interaction.memberPermissions.has(PermissionFlagsBits.ManageGuild)) {
    return interaction.reply({
      content: '❌ No tienes permisos de \`Gestionar Servidor\` para usar este comando.',
      ephemeral: true
    });
  }

  const subcommand = interaction.options.getSubcommand();

  if (subcommand === 'ticket-panel') {
    const config = getGuildConfig(interaction.guildId);
    const embed = buildConfigEmbed(config, interaction.guild);
    const components = buildConfigComponents(config);

    return interaction.reply({
      embeds: [embed],
      components,
      ephemeral: true
    });
  }
}`
  },
  {
    name: 'selectMenus.js',
    path: 'bot/interactions/selectMenus.js',
    language: 'javascript',
    description: 'Procesa la selección de categorías, canal de panel, roles de soporte y la creación de canales privados de tickets.',
    content: `import {
  ChannelType,
  PermissionFlagsBits,
  EmbedBuilder
} from 'discord.js';
import {
  getGuildConfig,
  updateGuildConfig,
  incrementTicketCounter,
  saveActiveTicket
} from '../storage.js';
import {
  buildTicketWelcomeEmbed,
  buildConfigEmbed,
  buildConfigComponents
} from '../utils/embeds.js';

export async function handleSelectMenu(interaction) {
  const { customId, guild, user } = interaction;
  const config = getGuildConfig(guild.id);

  // 1. Selección de /set category-tickets
  if (customId === 'set_category_tickets_select') {
    const selectedCategoryId = interaction.values[0];
    const category = guild.channels.cache.get(selectedCategoryId);

    if (!category || category.type !== ChannelType.GuildCategory) {
      return interaction.reply({ content: '❌ Categoría no válida.', ephemeral: true });
    }

    updateGuildConfig(guild.id, { categoryId: selectedCategoryId });

    const confirmEmbed = new EmbedBuilder()
      .setColor(0x57F287)
      .setTitle('✅ Categoría de Tickets Configurada')
      .setDescription(\`Los tickets se crearán dentro de:\\n📁 **\${category.name}**\`)
      .setTimestamp();

    return interaction.update({ embeds: [confirmEmbed], components: [] });
  }

  // 2. Selección de /set ticket-channel
  if (customId === 'set_ticket_channel_select') {
    const selectedChannelId = interaction.values[0];
    const channel = guild.channels.cache.get(selectedChannelId);

    if (!channel) {
      return interaction.reply({ content: '❌ Canal no válido.', ephemeral: true });
    }

    updateGuildConfig(guild.id, { panelChannelId: selectedChannelId });

    const confirmEmbed = new EmbedBuilder()
      .setColor(0x57F287)
      .setTitle('✅ Canal del Panel Configurado')
      .setDescription(\`El panel se publicará en:\\n💬 <#\${channel.id}>\`)
      .setTimestamp();

    return interaction.update({ embeds: [confirmEmbed], components: [] });
  }

  // 4. Selección de /set staff-roles
  if (customId === 'set_staff_roles_select') {
    const selectedRoleIds = interaction.values;
    updateGuildConfig(guild.id, { staffRoleIds: selectedRoleIds });

    const mentions = selectedRoleIds.map(id => \`<@&\${id}>\`).join(', ');

    const confirmEmbed = new EmbedBuilder()
      .setColor(0x57F287)
      .setTitle('✅ Roles de Soporte Configurados')
      .setDescription(\`Roles asignados:\\n\${mentions}\\n\\n• Recibirán menciones y acceso a cada ticket.\`)
      .setTimestamp();

    return interaction.update({ embeds: [confirmEmbed], components: [] });
  }

  // Eliminación de categoría
  if (customId === 'cfg_delete_category_select') {
    const catIdToDelete = interaction.values[0];
    const updatedCategories = (config.panel.categories || []).filter(c => c.id !== catIdToDelete);

    const updatedConfig = updateGuildConfig(guild.id, {
      panel: { ...config.panel, categories: updatedCategories }
    });

    return interaction.update({
      embeds: [buildConfigEmbed(updatedConfig, guild)],
      components: buildConfigComponents(updatedConfig)
    });
  }

  // Usuario abre un ticket desde el menú del panel publicado
  if (customId === 'ticket_select_category') {
    const selectedCatId = interaction.values[0];
    const categoryConfig = (config.panel.categories || []).find(c => c.id === selectedCatId);

    if (!categoryConfig) {
      return interaction.reply({ content: '❌ Categoría no encontrada.', ephemeral: true });
    }

    if (!config.categoryId) {
      return interaction.reply({
        content: '⚠️ Falta configurar la categoría de tickets con \`/set category-tickets\`.',
        ephemeral: true
      });
    }

    await interaction.deferReply({ ephemeral: true });

    try {
      const ticketNumber = incrementTicketCounter(guild.id);
      const cleanUsername = user.username.toLowerCase().replace(/[^a-z0-9_-]/g, '').slice(0, 15) || 'user';
      const channelName = \`ticket-\${cleanUsername}-\${ticketNumber}\`;

      // Permisos privados
      const permissionOverwrites = [
        { id: guild.roles.everyone.id, deny: [PermissionFlagsBits.ViewChannel] },
        {
          id: user.id,
          allow: [
            PermissionFlagsBits.ViewChannel,
            PermissionFlagsBits.SendMessages,
            PermissionFlagsBits.ReadMessageHistory,
            PermissionFlagsBits.AttachFiles,
            PermissionFlagsBits.EmbedLinks
          ]
        },
        {
          id: guild.members.me.id,
          allow: [
            PermissionFlagsBits.ViewChannel,
            PermissionFlagsBits.SendMessages,
            PermissionFlagsBits.ManageChannels,
            PermissionFlagsBits.ReadMessageHistory
          ]
        }
      ];

      // Añadir roles de soporte
      if (Array.isArray(config.staffRoleIds)) {
        for (const roleId of config.staffRoleIds) {
          const role = guild.roles.cache.get(roleId);
          if (role) {
            permissionOverwrites.push({
              id: role.id,
              allow: [
                PermissionFlagsBits.ViewChannel,
                PermissionFlagsBits.SendMessages,
                PermissionFlagsBits.ReadMessageHistory,
                PermissionFlagsBits.AttachFiles,
                PermissionFlagsBits.EmbedLinks
              ]
            });
          }
        }
      }

      // Crear canal dentro de la categoría configurada
      const ticketChannel = await guild.channels.create({
        name: channelName,
        type: ChannelType.GuildText,
        parent: config.categoryId,
        topic: \`Ticket #\${ticketNumber} | Solicitante: \${user.tag || user.username} | Categoría: \${categoryConfig.label}\`,
        permissionOverwrites
      });

      saveActiveTicket(guild.id, ticketChannel.id, {
        userId: user.id,
        categoryId: selectedCatId,
        ticketNumber,
        createdAt: Date.now()
      });

      const { embed, buttonRow, staffMentions } = buildTicketWelcomeEmbed(user, categoryConfig, config);

      let content = null;
      if (staffMentions) {
        content = \`🔔 \${staffMentions} — ¡Nuevo ticket abierto por <@\${user.id}>!\`;
      }

      await ticketChannel.send({ content, embeds: [embed], components: [buttonRow] });

      return interaction.editReply({
        content: \`✅ ¡Tu ticket ha sido creado! Accede aquí: <#\${ticketChannel.id}>\`
      });
    } catch (err) {
      console.error('[TICKET_CREATE_ERROR]', err);
      return interaction.editReply({
        content: \`❌ Error al crear ticket: \${err.message}\`
      });
    }
  }
}`
  },
  {
    name: 'modals.js',
    path: 'bot/interactions/modals.js',
    language: 'javascript',
    description: 'Procesa los envíos de formularios modales para modificar textos, imagen, colores y categorías.',
    content: `import { getGuildConfig, updateGuildConfig } from '../storage.js';
import { buildConfigEmbed, buildConfigComponents } from '../utils/embeds.js';

export async function handleModalSubmit(interaction) {
  const { customId, guild } = interaction;
  const config = getGuildConfig(guild.id);

  // 1. Título y Mensaje
  if (customId === 'modal_cfg_text') {
    const title = interaction.fields.getTextInputValue('input_title').trim();
    const description = interaction.fields.getTextInputValue('input_description').trim();

    const updatedConfig = updateGuildConfig(guild.id, {
      panel: {
        ...config.panel,
        title: title || config.panel.title,
        description: description || config.panel.description
      }
    });

    return interaction.update({
      embeds: [buildConfigEmbed(updatedConfig, guild)],
      components: buildConfigComponents(updatedConfig)
    });
  }

  // 2. Imagen / Banner
  if (customId === 'modal_cfg_image') {
    let imageUrl = interaction.fields.getTextInputValue('input_image_url').trim();
    if (!imageUrl || imageUrl.toLowerCase() === 'quitar' || imageUrl.toLowerCase() === 'none') {
      imageUrl = null;
    }

    const updatedConfig = updateGuildConfig(guild.id, {
      panel: { ...config.panel, imageUrl }
    });

    return interaction.update({
      embeds: [buildConfigEmbed(updatedConfig, guild)],
      components: buildConfigComponents(updatedConfig)
    });
  }

  // 3. Color Hex
  if (customId === 'modal_cfg_color') {
    let color = interaction.fields.getTextInputValue('input_color').trim();
    if (!color.startsWith('#')) color = \`#\${color}\`;
    if (!/^#[0-9A-Fa-f]{6}$/.test(color)) color = '#5865F2';

    const updatedConfig = updateGuildConfig(guild.id, {
      panel: { ...config.panel, color }
    });

    return interaction.update({
      embeds: [buildConfigEmbed(updatedConfig, guild)],
      components: buildConfigComponents(updatedConfig)
    });
  }

  // 4. Añadir Categoría
  if (customId === 'modal_cfg_add_cat') {
    const label = interaction.fields.getTextInputValue('input_cat_label').trim();
    const emoji = interaction.fields.getTextInputValue('input_cat_emoji').trim() || '🎫';
    const description = interaction.fields.getTextInputValue('input_cat_desc').trim();
    let id = interaction.fields.getTextInputValue('input_cat_id')?.trim();

    if (!id) {
      id = label.toLowerCase().replace(/[^a-z0-9_-]/g, '_').slice(0, 30);
    }

    const newCategory = { id, label, emoji, description };
    const currentCats = [...(config.panel.categories || [])];
    const idx = currentCats.findIndex(c => c.id === id);

    if (idx >= 0) currentCats[idx] = newCategory;
    else currentCats.push(newCategory);

    const updatedConfig = updateGuildConfig(guild.id, {
      panel: { ...config.panel, categories: currentCats }
    });

    return interaction.update({
      embeds: [buildConfigEmbed(updatedConfig, guild)],
      components: buildConfigComponents(updatedConfig)
    });
  }
}`
  },
  {
    name: 'buttons.js',
    path: 'bot/interactions/buttons.js',
    language: 'javascript',
    description: 'Procesa los clics en botones de configuración, publicación del panel y confirmación de cierre de tickets.',
    content: `import {
  ModalBuilder,
  TextInputBuilder,
  TextInputStyle,
  ActionRowBuilder,
  StringSelectMenuBuilder,
  StringSelectMenuOptionBuilder
} from 'discord.js';
import { getGuildConfig, removeActiveTicket } from '../storage.js';
import {
  buildConfigEmbed,
  buildConfigComponents,
  buildPublishedPanelEmbed,
  buildTicketSelectMenu,
  buildCloseConfirmationRow
} from '../utils/embeds.js';

export async function handleButton(interaction) {
  const { customId, guild, channel, user } = interaction;
  const config = getGuildConfig(guild.id);

  // Botón Editar Título y Texto -> Abre Modal
  if (customId === 'btn_cfg_text') {
    const modal = new ModalBuilder()
      .setCustomId('modal_cfg_text')
      .setTitle('Editar Título y Mensaje del Panel');

    const titleInput = new TextInputBuilder()
      .setCustomId('input_title')
      .setLabel('Título del Panel')
      .setStyle(TextInputStyle.Short)
      .setValue(config.panel.title || '')
      .setRequired(true);

    const descInput = new TextInputBuilder()
      .setCustomId('input_description')
      .setLabel('Mensaje / Descripción del Panel')
      .setStyle(TextInputStyle.Paragraph)
      .setValue(config.panel.description || '')
      .setRequired(true);

    modal.addComponents(
      new ActionRowBuilder().addComponents(titleInput),
      new ActionRowBuilder().addComponents(descInput)
    );
    return interaction.showModal(modal);
  }

  // Botón Imagen / Banner -> Abre Modal
  if (customId === 'btn_cfg_image') {
    const modal = new ModalBuilder()
      .setCustomId('modal_cfg_image')
      .setTitle('Configurar Imagen o Banner');

    const imgInput = new TextInputBuilder()
      .setCustomId('input_image_url')
      .setLabel('URL de Imagen (o escribe "quitar")')
      .setStyle(TextInputStyle.Short)
      .setValue(config.panel.imageUrl || '')
      .setRequired(false);

    modal.addComponents(new ActionRowBuilder().addComponents(imgInput));
    return interaction.showModal(modal);
  }

  // Botón Color Embed -> Abre Modal
  if (customId === 'btn_cfg_color') {
    const modal = new ModalBuilder()
      .setCustomId('modal_cfg_color')
      .setTitle('Color del Embed (Hexadecimal)');

    const colorInput = new TextInputBuilder()
      .setCustomId('input_color')
      .setLabel('Código Hex (#5865F2, etc.)')
      .setStyle(TextInputStyle.Short)
      .setValue(config.panel.color || '#5865F2')
      .setRequired(true);

    modal.addComponents(new ActionRowBuilder().addComponents(colorInput));
    return interaction.showModal(modal);
  }

  // Botón Añadir Categoría -> Abre Modal
  if (customId === 'btn_cfg_add_cat') {
    const modal = new ModalBuilder()
      .setCustomId('modal_cfg_add_cat')
      .setTitle('Añadir Categoría de Ticket');

    const labelInput = new TextInputBuilder()
      .setCustomId('input_cat_label')
      .setLabel('Nombre de la Categoría')
      .setStyle(TextInputStyle.Short)
      .setRequired(true);

    const emojiInput = new TextInputBuilder()
      .setCustomId('input_cat_emoji')
      .setLabel('Emoji')
      .setStyle(TextInputStyle.Short)
      .setRequired(false);

    const descInput = new TextInputBuilder()
      .setCustomId('input_cat_desc')
      .setLabel('Descripción breve')
      .setStyle(TextInputStyle.Short)
      .setRequired(false);

    modal.addComponents(
      new ActionRowBuilder().addComponents(labelInput),
      new ActionRowBuilder().addComponents(emojiInput),
      new ActionRowBuilder().addComponents(descInput)
    );
    return interaction.showModal(modal);
  }

  // Botón Eliminar Categoría -> Selector
  if (customId === 'btn_cfg_del_cat') {
    const categories = config.panel.categories || [];
    const options = categories.map(cat =>
      new StringSelectMenuOptionBuilder()
        .setLabel(cat.label)
        .setValue(cat.id)
        .setDescription(cat.description || '')
        .setEmoji(cat.emoji || '🎫')
    );
    const select = new StringSelectMenuBuilder()
      .setCustomId('cfg_delete_category_select')
      .setPlaceholder('Elige la categoría a eliminar...')
      .addOptions(options);

    return interaction.reply({
      content: '🗑️ Selecciona la categoría que deseas eliminar:',
      components: [new ActionRowBuilder().addComponents(select)],
      ephemeral: true
    });
  }

  // Botón Refrescar
  if (customId === 'btn_cfg_refresh') {
    return interaction.update({
      embeds: [buildConfigEmbed(config, guild)],
      components: buildConfigComponents(config)
    });
  }

  // Botón Publicar Panel de Tickets
  if (customId === 'btn_cfg_publish') {
    if (!config.panelChannelId) {
      return interaction.reply({
        content: '❌ Configura primero el canal con \`/set ticket-channel\`.',
        ephemeral: true
      });
    }

    const target = guild.channels.cache.get(config.panelChannelId);
    if (!target) {
      return interaction.reply({ content: '❌ El canal configurado no existe.', ephemeral: true });
    }

    try {
      await target.send({
        embeds: [buildPublishedPanelEmbed(config, guild)],
        components: [buildTicketSelectMenu(config)]
      });

      return interaction.reply({
        content: \`🎉 **¡Panel publicado con éxito en <#\${target.id}>!**\`,
        ephemeral: true
      });
    } catch (err) {
      return interaction.reply({
        content: \`❌ Error al enviar el panel: \${err.message}\`,
        ephemeral: true
      });
    }
  }

  // Cerrar Ticket
  if (customId === 'ticket_btn_close') {
    return interaction.reply({
      content: '⚠️ **¿Estás seguro de que deseas cerrar este ticket?**',
      components: [buildCloseConfirmationRow()]
    });
  }

  // Confirmar Cierre de Ticket
  if (customId === 'ticket_btn_confirm_close') {
    await interaction.update({
      content: \`🔒 **Ticket cerrado por <@\${user.id}>.** Eliminando canal en 5 segundos...\`,
      components: []
    });

    removeActiveTicket(guild.id, channel.id);

    setTimeout(async () => {
      try {
        if (channel?.deletable) await channel.delete();
      } catch (e) {
        console.error(e);
      }
    }, 5000);
  }

  // Cancelar Cierre
  if (customId === 'ticket_btn_cancel_close') {
    return interaction.update({
      content: '✅ Cierre cancelado. El ticket permanece abierto.',
      components: []
    });
  }
}`
  },
  {
    name: 'storage.js',
    path: 'bot/storage.js',
    language: 'javascript',
    description: 'Gestión de persistencia de datos en disco mediante JSON seguro para cada servidor de Discord.',
    content: `import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const DATA_DIR = path.join(__dirname, 'data');
const DATA_FILE = path.join(DATA_DIR, 'guilds.json');

if (!fs.existsSync(DATA_DIR)) {
  fs.mkdirSync(DATA_DIR, { recursive: true });
}

const DEFAULT_CONFIG = {
  categoryId: null,
  panelChannelId: null,
  staffRoleIds: [],
  ticketCounter: 0,
  panel: {
    title: '🎫 Sistema de Tickets de Soporte',
    description: 'Bienvenido a nuestro centro de atención. Selecciona una categoría para abrir un ticket.',
    imageUrl: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?q=80&w=1200&auto=format&fit=crop',
    color: '#5865F2',
    placeholder: 'Elige una categoría...',
    categories: [
      { id: 'soporte_general', label: 'Soporte General', description: 'Consultas generales', emoji: '❓' },
      { id: 'compras_facturacion', label: 'Compras & Donaciones', description: 'Pagos y rangos', emoji: '💳' },
      { id: 'reportes_moderacion', label: 'Reportes & Moderación', description: 'Denuncias y apelaciones', emoji: '🛡️' }
    ]
  },
  activeTickets: {}
};

function readAllData() {
  try {
    if (!fs.existsSync(DATA_FILE)) {
      fs.writeFileSync(DATA_FILE, JSON.stringify({}, null, 2), 'utf-8');
      return {};
    }
    return JSON.parse(fs.readFileSync(DATA_FILE, 'utf-8'));
  } catch (err) {
    return {};
  }
}

function writeAllData(data) {
  try {
    const tmp = \`\${DATA_FILE}.tmp\`;
    fs.writeFileSync(tmp, JSON.stringify(data, null, 2), 'utf-8');
    fs.renameSync(tmp, DATA_FILE);
    return true;
  } catch (err) {
    return false;
  }
}

export function getGuildConfig(guildId) {
  const all = readAllData();
  if (!all[guildId]) {
    all[guildId] = JSON.parse(JSON.stringify(DEFAULT_CONFIG));
    writeAllData(all);
  }
  return all[guildId];
}

export function updateGuildConfig(guildId, updates) {
  const all = readAllData();
  const current = getGuildConfig(guildId);
  const updated = {
    ...current,
    ...updates,
    panel: { ...current.panel, ...(updates.panel || {}) }
  };
  all[guildId] = updated;
  writeAllData(all);
  return updated;
}

export function incrementTicketCounter(guildId) {
  const config = getGuildConfig(guildId);
  config.ticketCounter = (config.ticketCounter || 0) + 1;
  updateGuildConfig(guildId, { ticketCounter: config.ticketCounter });
  return config.ticketCounter;
}

export function saveActiveTicket(guildId, channelId, data) {
  const config = getGuildConfig(guildId);
  config.activeTickets = config.activeTickets || {};
  config.activeTickets[channelId] = data;
  updateGuildConfig(guildId, { activeTickets: config.activeTickets });
}

export function removeActiveTicket(guildId, channelId) {
  const config = getGuildConfig(guildId);
  if (config.activeTickets?.[channelId]) {
    delete config.activeTickets[channelId];
    updateGuildConfig(guildId, { activeTickets: config.activeTickets });
  }
}`
  },
  {
    name: 'deploy-commands.js',
    path: 'bot/deploy-commands.js',
    language: 'javascript',
    description: 'Script para registrar los comandos slash en la API de Discord vía REST v10.',
    content: `import { REST, Routes } from 'discord.js';
import dotenv from 'dotenv';
import { data as setData } from './commands/set.js';
import { data as configData } from './commands/config.js';

dotenv.config();

const token = process.env.DISCORD_TOKEN;
const clientId = process.env.CLIENT_ID;
const guildId = process.env.GUILD_ID;

if (!token || token === 'TU_TOKEN_DE_DISCORD_AQUI') {
  console.error('❌ Falta DISCORD_TOKEN en .env');
  process.exit(1);
}

const commands = [setData.toJSON(), configData.toJSON()];
const rest = new REST({ version: '10' }).setToken(token);

(async () => {
  try {
    console.log(\`⏳ Registrando \${commands.length} comandos slash...\`);
    if (guildId) {
      await rest.put(Routes.applicationGuildCommands(clientId, guildId), { body: commands });
      console.log(\`✅ Comandos registrados al instante en el servidor \${guildId}!\`);
    } else {
      await rest.put(Routes.applicationCommands(clientId), { body: commands });
      console.log('✅ Comandos registrados globalmente en Discord!');
    }
  } catch (error) {
    console.error('❌ Error registrando comandos:', error);
  }
})();`
  },
  {
    name: '.env.example',
    path: '.env.example',
    language: 'bash',
    description: 'Variables de entorno requeridas para el token del bot y credenciales de Discord.',
    content: `DISCORD_TOKEN="TU_TOKEN_DE_DISCORD_AQUI"
CLIENT_ID="TU_CLIENT_ID_AQUI"
GUILD_ID=""`
  }
];
