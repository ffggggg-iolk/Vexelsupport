import React, { useState, useEffect, useRef } from 'react';
import {
  MessageSquare,
  Settings,
  Code2,
  BookOpen,
  Terminal,
  Shield,
  Folder,
  Hash,
  Users,
  Image as ImageIcon,
  Palette,
  Send,
  RefreshCw,
  Trash2,
  Plus,
  Play,
  Lock,
  AlertCircle,
  CheckCircle2,
  Copy,
  Check,
  ExternalLink,
  ChevronRight,
  ChevronDown,
  Sparkles,
  X,
  Clock,
  Radio,
  FileText,
  Ticket,
  Download
} from 'lucide-react';
import JSZip from 'jszip';
import { BOT_FILES, BotFile } from './data/botCode';

// Interfaces for Bot & Simulator State
interface TicketCategory {
  id: string;
  label: string;
  description: string;
  emoji: string;
}

interface GuildConfigState {
  categoryId: string | null;
  panelChannelId: string | null;
  staffRoleIds: string[];
  ticketCounter: number;
  panel: {
    title: string;
    description: string;
    imageUrl: string | null;
    color: string;
    placeholder: string;
    categories: TicketCategory[];
  };
  activeTickets: {
    [channelId: string]: {
      id: string;
      channelName: string;
      userId: string;
      userName: string;
      categoryId: string;
      categoryLabel: string;
      categoryEmoji: string;
      createdAt: number;
    };
  };
}

interface DiscordRole {
  id: string;
  name: string;
  color: string;
}

interface DiscordChannel {
  id: string;
  name: string;
  type: 'category' | 'text';
  parentId?: string;
}

const AVAILABLE_ROLES: DiscordRole[] = [
  { id: 'role_admin', name: 'Administrador', color: '#F1C40F' },
  { id: 'role_support', name: 'Soporte Técnico', color: '#3498DB' },
  { id: 'role_mod', name: 'Moderador', color: '#2ECC71' },
  { id: 'role_helper', name: 'Ayudante', color: '#9B59B6' }
];

const INITIAL_CHANNELS: DiscordChannel[] = [
  { id: 'cat_general', name: 'CANALES DE INFORMACIÓN', type: 'category' },
  { id: 'ch_reglas', name: 'reglas-y-normas', type: 'text', parentId: 'cat_general' },
  { id: 'ch_tickets', name: 'crear-ticket', type: 'text', parentId: 'cat_general' },
  { id: 'cat_community', name: 'COMUNIDAD', type: 'category' },
  { id: 'ch_general', name: 'chat-general', type: 'text', parentId: 'cat_community' },
  { id: 'cat_tickets_target', name: 'TICKETS - ATENCIÓN', type: 'category' }
];

export default function App() {
  const [activeTab, setActiveTab] = useState<'simulator' | 'code' | 'guide' | 'state'>('simulator');
  const [selectedFile, setSelectedFile] = useState<BotFile>(BOT_FILES[0]);
  const [copiedFile, setCopiedFile] = useState(false);
  const [copiedAll, setCopiedAll] = useState(false);

  // Guild Config State
  const [config, setConfig] = useState<GuildConfigState>(() => {
    return {
      categoryId: 'cat_tickets_target',
      panelChannelId: 'ch_tickets',
      staffRoleIds: ['role_support', 'role_admin'],
      ticketCounter: 1,
      panel: {
        title: '🎫 Sistema de Tickets de Soporte',
        description: '¡Bienvenido a nuestro centro de atención oficial!\n\nSi necesitas asistencia técnica, realizar consultas sobre donaciones o reportar un usuario, selecciona la categoría correspondiente en el menú desplegable a continuación.\n\nUn miembro de nuestro equipo te atenderá a la brevedad.',
        imageUrl: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?q=80&w=1200&auto=format&fit=crop',
        color: '#5865F2',
        placeholder: 'Selecciona el motivo de tu consulta...',
        categories: [
          {
            id: 'soporte_general',
            label: 'Soporte General',
            description: 'Dudas, preguntas frecuentes y asistencia sobre el servidor',
            emoji: '❓'
          },
          {
            id: 'compras_facturacion',
            label: 'Compras & Donaciones',
            description: 'Problemas con pagos, suscripciones y rangos',
            emoji: '💳'
          },
          {
            id: 'reportes_moderacion',
            label: 'Reportes & Moderación',
            description: 'Denuncias de usuarios, problemas o apelaciones',
            emoji: '🛡️'
          }
        ]
      },
      activeTickets: {}
    };
  });

  // Simulator navigation & messages
  const [currentChannelId, setCurrentChannelId] = useState<string>('ch_tickets');
  const [panelPublishedIn, setPanelPublishedIn] = useState<string | null>('ch_tickets');
  
  // Interactive Modal State
  const [activeModal, setActiveModal] = useState<
    'none' | 'modal_text' | 'modal_image' | 'modal_color' | 'modal_add_cat'
  >('none');

  // Modal Inputs
  const [modalTitle, setModalTitle] = useState(config.panel.title);
  const [modalDescription, setModalDescription] = useState(config.panel.description);
  const [modalImageUrl, setModalImageUrl] = useState(config.panel.imageUrl || '');
  const [modalColor, setModalColor] = useState(config.panel.color);
  const [modalCatLabel, setModalCatLabel] = useState('');
  const [modalCatEmoji, setModalCatEmoji] = useState('🎫');
  const [modalCatDesc, setModalCatDesc] = useState('');

  // Dropdown menus states in chat
  const [showCategorySelectMenu, setShowCategorySelectMenu] = useState(false);
  const [showChannelSelectMenu, setShowChannelSelectMenu] = useState(false);
  const [showRoleSelectMenu, setShowRoleSelectMenu] = useState(false);
  const [showConfigEmbedInChat, setShowConfigEmbedInChat] = useState(false);
  const [showDeleteCatSelectMenu, setShowDeleteCatSelectMenu] = useState(false);

  // Ticket closing state
  const [closingTicketId, setClosingTicketId] = useState<string | null>(null);
  const [closeCountdown, setCloseCountdown] = useState<number | null>(null);

  // Toast message
  const [toast, setToast] = useState<string | null>(null);

  const showToast = (msg: string) => {
    setToast(msg);
    setTimeout(() => setToast(null), 3000);
  };

  const [isDownloadingZip, setIsDownloadingZip] = useState(false);

  const handleDownloadZip = async () => {
    try {
      setIsDownloadingZip(true);
      showToast('📦 Preparando archivo ZIP del proyecto...');
      const zip = new JSZip();

      // Add all bot files
      BOT_FILES.forEach(file => {
        zip.file(file.path, file.content);
      });

      // Add package.json
      zip.file(
        'package.json',
        JSON.stringify(
          {
            name: 'discord-ticket-bot',
            version: '1.0.0',
            type: 'module',
            main: 'bot/index.js',
            scripts: {
              start: 'node bot/deploy-commands.js && node bot/index.js',
              bot: 'node bot/index.js',
              'deploy:commands': 'node bot/deploy-commands.js'
            },
            dependencies: {
              'discord.js': '^14.27.0',
              dotenv: '^17.2.3'
            }
          },
          null,
          2
        )
      );

      // Add .gitignore
      zip.file(
        '.gitignore',
        `node_modules/
.env
dist/
*.tmp
`
      );

      // Add .env.example
      zip.file(
        '.env.example',
        `DISCORD_TOKEN="TU_TOKEN_DE_DISCORD_AQUI"
CLIENT_ID="TU_CLIENT_ID_AQUI"
GUILD_ID=""
`
      );

      const content = await zip.generateAsync({ type: 'blob' });
      const url = URL.createObjectURL(content);
      const a = document.createElement('a');
      a.href = url;
      a.download = 'discord-ticket-bot.zip';
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);

      setIsDownloadingZip(false);
      showToast('🎉 ¡Descarga completada! (discord-ticket-bot.zip)');
    } catch (err) {
      console.error('Error generating zip:', err);
      setIsDownloadingZip(false);
      showToast('❌ Error al generar ZIP.');
    }
  };

  const handleCopyCode = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedFile(true);
    showToast('¡Código copiado al portapapeles!');
    setTimeout(() => setCopiedFile(false), 2000);
  };

  // Close ticket with 5 second countdown
  const confirmCloseTicket = (channelId: string) => {
    setCloseCountdown(5);
    const interval = setInterval(() => {
      setCloseCountdown(prev => {
        if (prev === null || prev <= 1) {
          clearInterval(interval);
          // Delete ticket
          setConfig(prevCfg => {
            const updated = { ...prevCfg.activeTickets };
            delete updated[channelId];
            return { ...prevCfg, activeTickets: updated };
          });
          setClosingTicketId(null);
          setCurrentChannelId(config.panelChannelId || 'ch_tickets');
          showToast('🔒 Ticket cerrado y canal eliminado.');
          return null;
        }
        return prev - 1;
      });
    }, 1000);
  };

  // Create ticket handler
  const handleOpenTicket = (categoryId: string) => {
    const cat = config.panel.categories.find(c => c.id === categoryId);
    if (!cat) return;

    // Check if user already has ticket
    const existing = Object.values(config.activeTickets).find(t => t.userId === 'user_123');
    if (existing) {
      showToast('⚠️ Ya tienes un ticket activo abierto.');
      setCurrentChannelId(existing.id);
      return;
    }

    const nextNumber = config.ticketCounter + 1;
    const ticketId = `ticket_ch_${Date.now()}`;
    const channelName = `ticket-usuario-${nextNumber}`;

    const newTicket = {
      id: ticketId,
      channelName,
      userId: 'user_123',
      userName: 'Bruno Renzo',
      categoryId: cat.id,
      categoryLabel: cat.label,
      categoryEmoji: cat.emoji,
      createdAt: Date.now()
    };

    setConfig(prev => ({
      ...prev,
      ticketCounter: nextNumber,
      activeTickets: {
        ...prev.activeTickets,
        [ticketId]: newTicket
      }
    }));

    setCurrentChannelId(ticketId);
    showToast(`✅ ¡Ticket creado! Redirigiendo a #${channelName}`);
  };

  const currentChannel = INITIAL_CHANNELS.find(c => c.id === currentChannelId);
  const currentTicket = config.activeTickets[currentChannelId];

  return (
    <div className="flex flex-col h-screen w-full bg-[#1e1f22] text-[#dbdee1] font-sans antialiased overflow-hidden select-none">
      {/* Toast Notification */}
      {toast && (
        <div className="fixed top-5 right-5 z-50 flex items-center gap-2 bg-[#5865F2] text-white px-4 py-2.5 rounded-lg shadow-2xl border border-white/20 animate-bounce text-sm font-medium">
          <Sparkles className="w-4 h-4" />
          <span>{toast}</span>
        </div>
      )}

      {/* TOP HEADER / APP NAVIGATION */}
      <header className="h-14 bg-[#111214] border-b border-[#2b2d31] flex items-center justify-between px-4 shrink-0">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded-lg bg-[#5865F2] flex items-center justify-center text-white font-bold shadow-md">
            🎫
          </div>
          <div>
            <h1 className="text-sm font-bold text-white flex items-center gap-2">
              Discord Ticket Bot
              <span className="text-[10px] bg-[#5865F2]/20 text-[#5865F2] font-semibold px-2 py-0.5 rounded border border-[#5865F2]/30">
                discord.js v14
              </span>
            </h1>
            <p className="text-[11px] text-[#949ba4]">
              4 Comandos: /set category-tickets • /set ticket-channel • /config ticket-panel • /set staff-roles
            </p>
          </div>
        </div>

        {/* Tab Buttons */}
        <div className="flex items-center bg-[#2b2d31] p-1 rounded-lg border border-[#35373c]">
          <button
            onClick={() => setActiveTab('simulator')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-md text-xs font-semibold transition ${
              activeTab === 'simulator'
                ? 'bg-[#5865F2] text-white shadow'
                : 'text-[#949ba4] hover:text-white hover:bg-[#35373c]'
            }`}
          >
            <Play className="w-3.5 h-3.5" />
            Simulador Discord
          </button>
          <button
            onClick={() => setActiveTab('code')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-md text-xs font-semibold transition ${
              activeTab === 'code'
                ? 'bg-[#5865F2] text-white shadow'
                : 'text-[#949ba4] hover:text-white hover:bg-[#35373c]'
            }`}
          >
            <Code2 className="w-3.5 h-3.5" />
            Código del Bot ({BOT_FILES.length} archivos)
          </button>
          <button
            onClick={() => setActiveTab('guide')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-md text-xs font-semibold transition ${
              activeTab === 'guide'
                ? 'bg-[#5865F2] text-white shadow'
                : 'text-[#949ba4] hover:text-white hover:bg-[#35373c]'
            }`}
          >
            <BookOpen className="w-3.5 h-3.5" />
            Guía de Instalación
          </button>
          <button
            onClick={() => setActiveTab('state')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-md text-xs font-semibold transition ${
              activeTab === 'state'
                ? 'bg-[#5865F2] text-white shadow'
                : 'text-[#949ba4] hover:text-white hover:bg-[#35373c]'
            }`}
          >
            <Terminal className="w-3.5 h-3.5" />
            Estado JSON en Disco
          </button>
        </div>

        {/* 1-Click ZIP Download Button */}
        <button
          onClick={handleDownloadZip}
          disabled={isDownloadingZip}
          className="flex items-center gap-1.5 bg-[#23a55a] hover:bg-[#1a8346] text-white px-3 py-1.5 rounded-lg text-xs font-semibold shadow-md transition shrink-0 border border-white/10"
        >
          <Download className="w-3.5 h-3.5" />
          <span>{isDownloadingZip ? 'Comprimiendo...' : 'Descargar ZIP'}</span>
        </button>
      </header>

      {/* MAIN CONTENT AREA */}
      <div className="flex-1 flex overflow-hidden">
        {/* ================= TAB 1: SIMULATOR ================= */}
        {activeTab === 'simulator' && (
          <div className="flex-1 flex w-full h-full overflow-hidden">
            {/* 1. DISCORD GUILD ICON BAR */}
            <div className="w-[72px] bg-[#1e1f22] border-r border-[#2b2d31] flex flex-col items-center py-3 gap-2 shrink-0">
              <div className="relative group cursor-pointer">
                <div className="w-12 h-12 rounded-[24px] group-hover:rounded-[16px] bg-[#5865F2] flex items-center justify-center text-white transition-all duration-200 shadow-md">
                  <Shield className="w-6 h-6" />
                </div>
                <div className="absolute -left-1 top-2.5 w-1 h-7 bg-white rounded-r-full" />
              </div>

              <div className="w-8 h-[2px] bg-[#35373c] my-1 rounded-full" />

              <div className="w-12 h-12 rounded-[24px] hover:rounded-[16px] bg-[#2b2d31] hover:bg-[#23a55a] text-[#dbdee1] hover:text-white flex items-center justify-center transition-all duration-200 cursor-pointer">
                <Plus className="w-6 h-6" />
              </div>
            </div>

            {/* 2. CHANNELS SIDEBAR */}
            <div className="w-60 bg-[#2b2d31] flex flex-col shrink-0 border-r border-[#1f2023]">
              {/* Server Name Header */}
              <div className="h-12 border-b border-[#1f2023] px-4 flex items-center justify-between font-bold text-white shadow-sm">
                <span className="truncate">Servidor de Soporte</span>
                <ChevronDown className="w-4 h-4 text-[#949ba4]" />
              </div>

              {/* Channels List */}
              <div className="flex-1 overflow-y-auto px-2 py-3 space-y-4">
                {/* Regular Category 1 */}
                <div>
                  <div className="flex items-center gap-1 text-[11px] font-bold text-[#949ba4] px-1 mb-1 tracking-wider uppercase">
                    <ChevronDown className="w-3 h-3" />
                    <span>CANALES DE INFORMACIÓN</span>
                  </div>
                  <div className="space-y-0.5">
                    <div
                      onClick={() => setCurrentChannelId('ch_reglas')}
                      className={`flex items-center gap-2 px-2 py-1.5 rounded text-sm cursor-pointer transition ${
                        currentChannelId === 'ch_reglas'
                          ? 'bg-[#404249] text-white font-medium'
                          : 'text-[#949ba4] hover:bg-[#35373c] hover:text-[#dbdee1]'
                      }`}
                    >
                      <Hash className="w-4 h-4 text-[#80848e]" />
                      <span>reglas-y-normas</span>
                    </div>

                    <div
                      onClick={() => setCurrentChannelId('ch_tickets')}
                      className={`flex items-center justify-between px-2 py-1.5 rounded text-sm cursor-pointer transition ${
                        currentChannelId === 'ch_tickets'
                          ? 'bg-[#404249] text-white font-medium'
                          : 'text-[#949ba4] hover:bg-[#35373c] hover:text-[#dbdee1]'
                      }`}
                    >
                      <div className="flex items-center gap-2 truncate">
                        <Hash className="w-4 h-4 text-[#80848e]" />
                        <span className="truncate">crear-ticket</span>
                      </div>
                      {config.panelChannelId === 'ch_tickets' && (
                        <span className="text-[10px] bg-[#5865F2]/30 text-[#8590f5] px-1.5 py-0.2 rounded font-mono">
                          PANEL
                        </span>
                      )}
                    </div>
                  </div>
                </div>

                {/* Regular Category 2 */}
                <div>
                  <div className="flex items-center gap-1 text-[11px] font-bold text-[#949ba4] px-1 mb-1 tracking-wider uppercase">
                    <ChevronDown className="w-3 h-3" />
                    <span>COMUNIDAD</span>
                  </div>
                  <div
                    onClick={() => setCurrentChannelId('ch_general')}
                    className={`flex items-center gap-2 px-2 py-1.5 rounded text-sm cursor-pointer transition ${
                      currentChannelId === 'ch_general'
                        ? 'bg-[#404249] text-white font-medium'
                        : 'text-[#949ba4] hover:bg-[#35373c] hover:text-[#dbdee1]'
                    }`}
                  >
                    <Hash className="w-4 h-4 text-[#80848e]" />
                    <span>chat-general</span>
                  </div>
                </div>

                {/* TICKETS CATEGORY (CONFIGURED WITH /set category-tickets) */}
                <div className="pt-2 border-t border-[#35373c]">
                  <div className="flex items-center justify-between text-[11px] font-bold text-[#5865F2] px-1 mb-1 tracking-wider uppercase">
                    <div className="flex items-center gap-1">
                      <Folder className="w-3.5 h-3.5" />
                      <span>📁 TICKETS - ATENCIÓN</span>
                    </div>
                    {config.categoryId === 'cat_tickets_target' && (
                      <span className="text-[9px] bg-[#23a55a]/20 text-[#23a55a] px-1.5 rounded font-mono">
                        ACTIVA
                      </span>
                    )}
                  </div>

                  {/* Active Ticket Channels */}
                  <div className="space-y-0.5">
                    {Object.values(config.activeTickets).length === 0 ? (
                      <div className="px-2 py-1 text-xs text-[#80848e] italic">
                        No hay tickets abiertos
                      </div>
                    ) : (
                      Object.values(config.activeTickets).map(ticket => (
                        <div
                          key={ticket.id}
                          onClick={() => setCurrentChannelId(ticket.id)}
                          className={`flex items-center justify-between px-2 py-1.5 rounded text-sm cursor-pointer transition ${
                            currentChannelId === ticket.id
                              ? 'bg-[#5865F2]/20 text-[#5865F2] font-semibold border-l-2 border-[#5865F2]'
                              : 'text-[#dbdee1] hover:bg-[#35373c]'
                          }`}
                        >
                          <div className="flex items-center gap-1.5 truncate">
                            <Lock className="w-3.5 h-3.5 text-[#f0b232]" />
                            <span className="truncate">{ticket.channelName}</span>
                          </div>
                          <span className="text-xs">{ticket.categoryEmoji}</span>
                        </div>
                      ))
                    )}
                  </div>
                </div>
              </div>

              {/* User Profile Bar */}
              <div className="h-14 bg-[#232428] px-2 flex items-center justify-between shrink-0">
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 rounded-full bg-[#5865F2] flex items-center justify-center font-bold text-white text-xs">
                    BR
                  </div>
                  <div>
                    <div className="text-xs font-semibold text-white">jaquebrunorenzoyari</div>
                    <div className="text-[10px] text-[#949ba4]">#7973</div>
                  </div>
                </div>
                <div className="flex items-center gap-1 text-[#949ba4]">
                  <Settings className="w-4 h-4 cursor-pointer hover:text-white" />
                </div>
              </div>
            </div>

            {/* 3. MAIN CHAT / CHANNEL VIEW */}
            <div className="flex-1 flex flex-col bg-[#313338] overflow-hidden">
              {/* Channel Header Bar */}
              <div className="h-12 border-b border-[#202225] px-4 flex items-center justify-between shadow-sm bg-[#313338] shrink-0">
                <div className="flex items-center gap-2">
                  {currentTicket ? (
                    <>
                      <Lock className="w-5 h-5 text-[#f0b232]" />
                      <span className="font-bold text-white">{currentTicket.channelName}</span>
                      <span className="text-xs text-[#949ba4] border-l border-[#3f4147] pl-2 ml-1">
                        Categoría: {currentTicket.categoryEmoji} {currentTicket.categoryLabel}
                      </span>
                    </>
                  ) : (
                    <>
                      <Hash className="w-5 h-5 text-[#80848e]" />
                      <span className="font-bold text-white">
                        {currentChannel?.name || 'canal-discord'}
                      </span>
                      {currentChannelId === 'ch_tickets' && (
                        <span className="text-xs text-[#949ba4] border-l border-[#3f4147] pl-2 ml-1">
                          Canal configurado para el panel de tickets
                        </span>
                      )}
                    </>
                  )}
                </div>

                {/* Staff roles indicator in current view */}
                <div className="flex items-center gap-1.5 text-xs text-[#949ba4]">
                  <Users className="w-4 h-4" />
                  <span>Roles de Soporte con acceso:</span>
                  <div className="flex items-center gap-1">
                    {config.staffRoleIds.map(rId => {
                      const r = AVAILABLE_ROLES.find(x => x.id === rId);
                      return (
                        <span
                          key={rId}
                          className="px-1.5 py-0.5 rounded text-[10px] font-semibold"
                          style={{
                            backgroundColor: `${r?.color || '#5865F2'}22`,
                            color: r?.color || '#5865F2'
                          }}
                        >
                          @{r?.name || rId}
                        </span>
                      );
                    })}
                  </div>
                </div>
              </div>

              {/* QUICK SLASH COMMAND TRIGGER BAR */}
              <div className="bg-[#2b2d31] border-b border-[#232428] px-4 py-2 flex items-center gap-2 overflow-x-auto shrink-0">
                <div className="flex items-center gap-1 text-xs font-bold text-[#b5bac1] uppercase tracking-wider shrink-0 mr-1">
                  <Terminal className="w-3.5 h-3.5 text-[#5865F2]" />
                  <span>Comandos:</span>
                </div>

                {/* Command 1: /set category-tickets */}
                <button
                  onClick={() => {
                    setShowCategorySelectMenu(true);
                    showToast('Comando ejecutado: /set category-tickets');
                  }}
                  className="flex items-center gap-1 bg-[#383a40] hover:bg-[#404249] text-white px-2.5 py-1 rounded text-xs font-mono font-medium transition shrink-0 border border-white/5 shadow-sm"
                >
                  <span className="text-[#5865F2] font-bold">/set</span> category-tickets
                </button>

                {/* Command 2: /set ticket-channel */}
                <button
                  onClick={() => {
                    setShowChannelSelectMenu(true);
                    showToast('Comando ejecutado: /set ticket-channel');
                  }}
                  className="flex items-center gap-1 bg-[#383a40] hover:bg-[#404249] text-white px-2.5 py-1 rounded text-xs font-mono font-medium transition shrink-0 border border-white/5 shadow-sm"
                >
                  <span className="text-[#5865F2] font-bold">/set</span> ticket-channel
                </button>

                {/* Command 4: /set staff-roles */}
                <button
                  onClick={() => {
                    setShowRoleSelectMenu(true);
                    showToast('Comando ejecutado: /set staff-roles');
                  }}
                  className="flex items-center gap-1 bg-[#383a40] hover:bg-[#404249] text-white px-2.5 py-1 rounded text-xs font-mono font-medium transition shrink-0 border border-white/5 shadow-sm"
                >
                  <span className="text-[#5865F2] font-bold">/set</span> staff-roles
                </button>

                {/* Command 3: /config ticket-panel */}
                <button
                  onClick={() => {
                    setShowConfigEmbedInChat(true);
                    showToast('Comando ejecutado: /config ticket-panel');
                  }}
                  className="flex items-center gap-1 bg-[#5865F2] hover:bg-[#4752c4] text-white px-3 py-1 rounded text-xs font-mono font-medium transition shrink-0 shadow-sm"
                >
                  <span className="font-bold">/config</span> ticket-panel
                </button>
              </div>

              {/* CHAT MESSAGES CONTENT SCROLL AREA */}
              <div className="flex-1 overflow-y-auto p-4 space-y-5">
                {/* 1. TICKET CHANNEL SPECIFIC VIEW */}
                {currentTicket ? (
                  <div className="space-y-4">
                    {/* Welcome message in ticket channel */}
                    <div className="bg-[#2b2d31]/50 border border-[#3f4147] rounded-lg p-3 text-sm">
                      <div className="flex items-center gap-2 text-[#57F287] font-semibold text-xs mb-1">
                        <CheckCircle2 className="w-4 h-4" />
                        <span>Canal de Ticket Creado Automáticamente</span>
                      </div>
                      <p className="text-xs text-[#949ba4]">
                        Este canal solo es visible para el solicitante (<span className="text-white font-medium">@{currentTicket.userName}</span>) y los roles de soporte configurados.
                      </p>
                    </div>

                    {/* Staff mentions */}
                    <div className="flex items-center gap-1.5 text-xs text-[#dbdee1]">
                      <span>🔔</span>
                      {config.staffRoleIds.map(rId => {
                        const r = AVAILABLE_ROLES.find(x => x.id === rId);
                        return (
                          <span
                            key={rId}
                            className="bg-[#5865F2]/20 text-[#5865F2] px-1.5 py-0.5 rounded font-semibold"
                          >
                            @{r?.name}
                          </span>
                        );
                      })}
                      <span>— ¡Nuevo ticket abierto por @{currentTicket.userName}!</span>
                    </div>

                    {/* TICKET WELCOME EMBED */}
                    <div
                      className="max-w-xl rounded-md bg-[#2b2d31] p-4 text-sm border-l-4 shadow-lg space-y-3"
                      style={{ borderLeftColor: config.panel.color || '#5865F2' }}
                    >
                      <div className="flex items-center justify-between">
                        <h3 className="text-base font-bold text-white flex items-center gap-2">
                          🎫 Ticket de Soporte #{config.ticketCounter}
                        </h3>
                        <span className="text-[11px] text-[#949ba4]">Hoy a las 14:00</span>
                      </div>

                      <p className="text-sm text-[#dbdee1] leading-relaxed">
                        Hola <span className="text-[#5865F2] font-semibold">@{currentTicket.userName}</span>, gracias por comunicarte con nosotros.
                        <br />
                        <br />
                        <strong>Categoría:</strong> {currentTicket.categoryEmoji}{' '}
                        <strong>{currentTicket.categoryLabel}</strong>
                        <br />
                        <strong>Detalles:</strong> Consulta personalizada para este departamento.
                        <br />
                        <br />
                        Por favor describe detalladamente tu problema o requerimiento. Nuestro equipo de soporte te atenderá en breve.
                      </p>

                      <div className="grid grid-cols-2 gap-2 text-xs pt-2 border-t border-[#35373c]">
                        <div>
                          <span className="text-[#949ba4] block">Solicitante:</span>
                          <span className="text-white font-medium">@{currentTicket.userName}</span>
                        </div>
                        <div>
                          <span className="text-[#949ba4] block">Estado:</span>
                          <span className="text-[#57F287] font-medium flex items-center gap-1">
                            <span className="w-2 h-2 rounded-full bg-[#57F287] inline-block" />
                            Abierto y activo
                          </span>
                        </div>
                      </div>

                      {/* CLOSE TICKET BUTTON */}
                      <div className="pt-2">
                        {closingTicketId === currentTicket.id ? (
                          <div className="bg-[#da373c]/10 border border-[#da373c]/30 p-3 rounded space-y-2">
                            {closeCountdown !== null ? (
                              <div className="flex items-center gap-2 text-sm text-[#da373c] font-bold">
                                <Clock className="w-4 h-4 animate-spin" />
                                <span>
                                  🔒 Ticket cerrado. Eliminando canal en {closeCountdown} segundos...
                                </span>
                              </div>
                            ) : (
                              <>
                                <p className="text-xs text-[#da373c] font-semibold">
                                  ⚠️ ¿Estás seguro de que deseas cerrar este ticket? El canal será eliminado.
                                </p>
                                <div className="flex items-center gap-2">
                                  <button
                                    onClick={() => confirmCloseTicket(currentTicket.id)}
                                    className="bg-[#da373c] hover:bg-[#a1282c] text-white px-3 py-1.5 rounded text-xs font-semibold flex items-center gap-1.5 transition"
                                  >
                                    <Check className="w-3.5 h-3.5" />
                                    Confirmar Cierre
                                  </button>
                                  <button
                                    onClick={() => setClosingTicketId(null)}
                                    className="bg-[#4e5058] hover:bg-[#6d6f78] text-white px-3 py-1.5 rounded text-xs font-semibold transition"
                                  >
                                    Cancelar
                                  </button>
                                </div>
                              </>
                            )}
                          </div>
                        ) : (
                          <button
                            onClick={() => setClosingTicketId(currentTicket.id)}
                            className="bg-[#da373c] hover:bg-[#a1282c] text-white px-4 py-2 rounded text-xs font-semibold flex items-center gap-2 transition shadow"
                          >
                            <Lock className="w-4 h-4" />
                            Cerrar Ticket
                          </button>
                        )}
                      </div>
                    </div>
                  </div>
                ) : (
                  <>
                    {/* Welcome banner of channel */}
                    <div className="space-y-1 mb-4">
                      <div className="w-12 h-12 rounded-full bg-[#404249] flex items-center justify-center text-white mb-2">
                        <Hash className="w-7 h-7 text-white" />
                      </div>
                      <h2 className="text-xl font-bold text-white">
                        ¡Te damos la bienvenida a #{currentChannel?.name}!
                      </h2>
                      <p className="text-xs text-[#949ba4]">
                        Este es el inicio del canal #{currentChannel?.name}.
                      </p>
                    </div>

                    {/* INTERACTIVE SELECT MENU 1: /set category-tickets */}
                    {showCategorySelectMenu && (
                      <div className="bg-[#2b2d31] p-4 rounded-lg border border-[#3f4147] max-w-lg space-y-3 shadow-md">
                        <div className="flex items-center justify-between text-xs text-[#949ba4]">
                          <span className="font-mono text-[#5865F2]">/set category-tickets</span>
                          <button
                            onClick={() => setShowCategorySelectMenu(false)}
                            className="hover:text-white"
                          >
                            <X className="w-3.5 h-3.5" />
                          </button>
                        </div>
                        <div className="text-sm font-semibold text-white flex items-center gap-1.5">
                          <Folder className="w-4 h-4 text-[#5865F2]" />
                          📁 Configurar Categoría de Tickets
                        </div>
                        <p className="text-xs text-[#dbdee1]">
                          Selecciona mediante el menú desplegable la <strong>categoría de Discord</strong> donde el bot creará automáticamente los tickets.
                        </p>

                        {/* Discord ChannelSelectMenu Simulator */}
                        <div className="space-y-1">
                          <label className="text-[11px] font-bold text-[#b5bac1] uppercase">
                            Channel Select Menu (GuildCategory)
                          </label>
                          <select
                            value={config.categoryId || ''}
                            onChange={e => {
                              setConfig(prev => ({ ...prev, categoryId: e.target.value }));
                              showToast('✅ Categoría de tickets guardada en guilds.json');
                            }}
                            className="w-full bg-[#1e1f22] border border-[#35373c] text-white rounded p-2.5 text-xs focus:outline-none focus:border-[#5865F2]"
                          >
                            <option value="">Selecciona una categoría...</option>
                            <option value="cat_tickets_target">📁 TICKETS - ATENCIÓN (Recomendada)</option>
                            <option value="cat_community">📁 COMUNIDAD</option>
                            <option value="cat_general">📁 CANALES DE INFORMACIÓN</option>
                          </select>
                        </div>

                        {config.categoryId && (
                          <div className="text-xs text-[#57F287] bg-[#57F287]/10 p-2 rounded flex items-center gap-1.5 font-medium">
                            <CheckCircle2 className="w-4 h-4 shrink-0" />
                            <span>
                              Categoría activa:{' '}
                              <strong>
                                {config.categoryId === 'cat_tickets_target'
                                  ? 'TICKETS - ATENCIÓN'
                                  : config.categoryId}
                              </strong>
                            </span>
                          </div>
                        )}
                      </div>
                    )}

                    {/* INTERACTIVE SELECT MENU 2: /set ticket-channel */}
                    {showChannelSelectMenu && (
                      <div className="bg-[#2b2d31] p-4 rounded-lg border border-[#3f4147] max-w-lg space-y-3 shadow-md">
                        <div className="flex items-center justify-between text-xs text-[#949ba4]">
                          <span className="font-mono text-[#5865F2]">/set ticket-channel</span>
                          <button
                            onClick={() => setShowChannelSelectMenu(false)}
                            className="hover:text-white"
                          >
                            <X className="w-3.5 h-3.5" />
                          </button>
                        </div>
                        <div className="text-sm font-semibold text-white flex items-center gap-1.5">
                          <Hash className="w-4 h-4 text-[#5865F2]" />
                          💬 Configurar Canal del Panel
                        </div>
                        <p className="text-xs text-[#dbdee1]">
                          Selecciona mediante el menú desplegable el <strong>canal de texto</strong> donde se publicará el panel de tickets.
                        </p>

                        {/* Discord ChannelSelectMenu Simulator */}
                        <div className="space-y-1">
                          <label className="text-[11px] font-bold text-[#b5bac1] uppercase">
                            Channel Select Menu (GuildText)
                          </label>
                          <select
                            value={config.panelChannelId || ''}
                            onChange={e => {
                              setConfig(prev => ({ ...prev, panelChannelId: e.target.value }));
                              showToast('✅ Canal del panel guardado en guilds.json');
                            }}
                            className="w-full bg-[#1e1f22] border border-[#35373c] text-white rounded p-2.5 text-xs focus:outline-none focus:border-[#5865F2]"
                          >
                            <option value="">Selecciona un canal de texto...</option>
                            <option value="ch_tickets">#crear-ticket (Recomendado)</option>
                            <option value="ch_general">#chat-general</option>
                            <option value="ch_reglas">#reglas-y-normas</option>
                          </select>
                        </div>

                        {config.panelChannelId && (
                          <div className="text-xs text-[#57F287] bg-[#57F287]/10 p-2 rounded flex items-center gap-1.5 font-medium">
                            <CheckCircle2 className="w-4 h-4 shrink-0" />
                            <span>
                              Canal activo: <strong>#{config.panelChannelId}</strong>
                            </span>
                          </div>
                        )}
                      </div>
                    )}

                    {/* INTERACTIVE SELECT MENU 4: /set staff-roles */}
                    {showRoleSelectMenu && (
                      <div className="bg-[#2b2d31] p-4 rounded-lg border border-[#3f4147] max-w-lg space-y-3 shadow-md">
                        <div className="flex items-center justify-between text-xs text-[#949ba4]">
                          <span className="font-mono text-[#5865F2]">/set staff-roles</span>
                          <button
                            onClick={() => setShowRoleSelectMenu(false)}
                            className="hover:text-white"
                          >
                            <X className="w-3.5 h-3.5" />
                          </button>
                        </div>
                        <div className="text-sm font-semibold text-white flex items-center gap-1.5">
                          <Shield className="w-4 h-4 text-[#5865F2]" />
                          🛡️ Configurar Roles de Soporte
                        </div>
                        <p className="text-xs text-[#dbdee1]">
                          Selecciona mediante el <strong>RoleSelectMenu</strong> los roles que recibirán menciones automáticas y acceso a los canales de tickets.
                        </p>

                        {/* Discord RoleSelectMenu Simulator with multi-select */}
                        <div className="space-y-2">
                          <label className="text-[11px] font-bold text-[#b5bac1] uppercase">
                            Role Select Menu (Selección Múltiple)
                          </label>
                          <div className="grid grid-cols-2 gap-2">
                            {AVAILABLE_ROLES.map(role => {
                              const isSelected = config.staffRoleIds.includes(role.id);
                              return (
                                <button
                                  key={role.id}
                                  onClick={() => {
                                    setConfig(prev => {
                                      const exists = prev.staffRoleIds.includes(role.id);
                                      const updated = exists
                                        ? prev.staffRoleIds.filter(id => id !== role.id)
                                        : [...prev.staffRoleIds, role.id];
                                      return { ...prev, staffRoleIds: updated };
                                    });
                                    showToast('Roles de soporte actualizados');
                                  }}
                                  className={`flex items-center justify-between p-2 rounded border text-xs text-left transition ${
                                    isSelected
                                      ? 'bg-[#5865F2]/20 border-[#5865F2] text-white'
                                      : 'bg-[#1e1f22] border-[#35373c] text-[#949ba4] hover:border-white/20'
                                  }`}
                                >
                                  <div className="flex items-center gap-1.5">
                                    <span
                                      className="w-2.5 h-2.5 rounded-full"
                                      style={{ backgroundColor: role.color }}
                                    />
                                    <span className="font-medium text-white">@{role.name}</span>
                                  </div>
                                  {isSelected && <Check className="w-3.5 h-3.5 text-[#5865F2]" />}
                                </button>
                              );
                            })}
                          </div>
                        </div>

                        <div className="text-xs text-[#57F287] bg-[#57F287]/10 p-2 rounded flex items-center gap-1.5 font-medium">
                          <CheckCircle2 className="w-4 h-4 shrink-0" />
                          <span>
                            {config.staffRoleIds.length} roles seleccionados: {' '}
                            {config.staffRoleIds
                              .map(id => AVAILABLE_ROLES.find(r => r.id === id)?.name)
                              .filter(Boolean)
                              .join(', ')}
                          </span>
                        </div>
                      </div>
                    )}

                    {/* INTERACTIVE CONFIG EMBED 3: /config ticket-panel */}
                    {showConfigEmbedInChat && (
                      <div className="bg-[#2b2d31] p-4 rounded-lg border border-[#3f4147] max-w-xl space-y-4 shadow-xl">
                        <div className="flex items-center justify-between text-xs text-[#949ba4]">
                          <span className="font-mono text-[#5865F2]">/config ticket-panel</span>
                          <button
                            onClick={() => setShowConfigEmbedInChat(false)}
                            className="hover:text-white"
                          >
                            <X className="w-3.5 h-3.5" />
                          </button>
                        </div>

                        {/* CONFIG EMBED PREVIEW */}
                        <div
                          className="rounded-md bg-[#1e1f22] p-4 text-xs border-l-4 space-y-3"
                          style={{ borderLeftColor: config.panel.color || '#5865F2' }}
                        >
                          <div className="flex items-center justify-between">
                            <h4 className="text-sm font-bold text-white flex items-center gap-1.5">
                              ⚙️ Panel de Configuración de Tickets
                            </h4>
                            <span className="text-[10px] bg-[#5865F2] text-white px-1.5 py-0.5 rounded font-mono">
                              Admin Panel
                            </span>
                          </div>

                          <p className="text-[#949ba4] text-[11px]">
                            Configura visualmente todos los aspectos de tu sistema de tickets. Los cambios se guardan automáticamente.
                          </p>

                          {/* Status Fields */}
                          <div className="bg-[#2b2d31] p-2.5 rounded space-y-1 text-[11px]">
                            <div className="font-bold text-[#b5bac1] mb-1">📌 Estado de Configuración:</div>
                            <div className="flex items-center gap-1">
                              <span className="text-[#949ba4]">• Categoría:</span>
                              <span className="text-white font-medium">
                                {config.categoryId ? '📁 TICKETS - ATENCIÓN' : '❌ No configurada (/set category-tickets)'}
                              </span>
                            </div>
                            <div className="flex items-center gap-1">
                              <span className="text-[#949ba4]">• Canal del Panel:</span>
                              <span className="text-white font-medium">
                                {config.panelChannelId ? `#${config.panelChannelId}` : '❌ No configurado (/set ticket-channel)'}
                              </span>
                            </div>
                            <div className="flex items-center gap-1">
                              <span className="text-[#949ba4]">• Roles Staff:</span>
                              <span className="text-[#5865F2] font-medium">
                                {config.staffRoleIds
                                  .map(id => `@${AVAILABLE_ROLES.find(r => r.id === id)?.name}`)
                                  .join(', ') || '❌ Ninguno (/set staff-roles)'}
                              </span>
                            </div>
                          </div>

                          {/* Title Preview */}
                          <div>
                            <div className="text-[10px] font-bold text-[#b5bac1] uppercase mb-0.5">Título Actual:</div>
                            <div className="text-white font-semibold">{config.panel.title}</div>
                          </div>

                          {/* Message Preview */}
                          <div>
                            <div className="text-[10px] font-bold text-[#b5bac1] uppercase mb-0.5">Descripción Actual:</div>
                            <p className="text-[#dbdee1] text-[11px] leading-relaxed line-clamp-3">
                              {config.panel.description}
                            </p>
                          </div>

                          {/* Image preview */}
                          {config.panel.imageUrl && (
                            <div className="overflow-hidden rounded border border-[#35373c] max-h-32">
                              <img
                                src={config.panel.imageUrl}
                                alt="Banner"
                                className="w-full h-28 object-cover"
                              />
                            </div>
                          )}

                          {/* Categories List */}
                          <div>
                            <div className="text-[10px] font-bold text-[#b5bac1] uppercase mb-1">
                              Categorías Configuradas ({config.panel.categories.length}/25):
                            </div>
                            <div className="space-y-1">
                              {config.panel.categories.map((cat, i) => (
                                <div
                                  key={cat.id}
                                  className="flex items-center justify-between bg-[#2b2d31] p-1.5 rounded text-[11px]"
                                >
                                  <div className="flex items-center gap-1.5">
                                    <span>{cat.emoji}</span>
                                    <span className="text-white font-medium">{cat.label}</span>
                                    <span className="text-[#80848e] text-[10px]">({cat.description})</span>
                                  </div>
                                  <span className="text-[9px] text-[#949ba4] font-mono">id: {cat.id}</span>
                                </div>
                              ))}
                            </div>
                          </div>
                        </div>

                        {/* CONFIG BUTTONS ROW 1 */}
                        <div className="grid grid-cols-2 sm:grid-cols-4 gap-1.5 pt-1">
                          <button
                            onClick={() => {
                              setModalTitle(config.panel.title);
                              setModalDescription(config.panel.description);
                              setActiveModal('modal_text');
                            }}
                            className="flex items-center justify-center gap-1 bg-[#5865F2] hover:bg-[#4752c4] text-white px-2 py-2 rounded text-xs font-semibold transition"
                          >
                            <FileText className="w-3.5 h-3.5" />
                            Editar Textos
                          </button>
                          <button
                            onClick={() => {
                              setModalImageUrl(config.panel.imageUrl || '');
                              setActiveModal('modal_image');
                            }}
                            className="flex items-center justify-center gap-1 bg-[#4e5058] hover:bg-[#6d6f78] text-white px-2 py-2 rounded text-xs font-semibold transition"
                          >
                            <ImageIcon className="w-3.5 h-3.5" />
                            Imagen Banner
                          </button>
                          <button
                            onClick={() => {
                              setModalColor(config.panel.color || '#5865F2');
                              setActiveModal('modal_color');
                            }}
                            className="flex items-center justify-center gap-1 bg-[#4e5058] hover:bg-[#6d6f78] text-white px-2 py-2 rounded text-xs font-semibold transition"
                          >
                            <Palette className="w-3.5 h-3.5" />
                            Color Embed
                          </button>
                          <button
                            onClick={() => {
                              setModalCatLabel('');
                              setModalCatEmoji('🎫');
                              setModalCatDesc('');
                              setActiveModal('modal_add_cat');
                            }}
                            className="flex items-center justify-center gap-1 bg-[#4e5058] hover:bg-[#6d6f78] text-white px-2 py-2 rounded text-xs font-semibold transition"
                          >
                            <Plus className="w-3.5 h-3.5" />
                            + Categoría
                          </button>
                        </div>

                        {/* CONFIG BUTTONS ROW 2 */}
                        <div className="flex items-center gap-2 pt-1">
                          <button
                            onClick={() => setShowDeleteCatSelectMenu(!showDeleteCatSelectMenu)}
                            className="flex items-center justify-center gap-1 bg-[#da373c] hover:bg-[#a1282c] text-white px-3 py-2 rounded text-xs font-semibold transition flex-1"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                            Eliminar Categoría
                          </button>
                          <button
                            onClick={() => {
                              setPanelPublishedIn(config.panelChannelId || 'ch_tickets');
                              showToast('🚀 ¡Panel publicado exitosamente en el canal!');
                            }}
                            className="flex items-center justify-center gap-1.5 bg-[#23a55a] hover:bg-[#1a8346] text-white px-4 py-2 rounded text-xs font-semibold transition flex-2 shadow-md"
                          >
                            <Send className="w-3.5 h-3.5" />
                            Publicar Panel en #{config.panelChannelId || 'crear-ticket'}
                          </button>
                        </div>

                        {/* Delete category submenu if open */}
                        {showDeleteCatSelectMenu && (
                          <div className="bg-[#1e1f22] p-2.5 rounded border border-[#da373c]/30 space-y-1.5">
                            <span className="text-[11px] font-bold text-[#da373c]">
                              Selecciona la categoría a eliminar:
                            </span>
                            <div className="space-y-1">
                              {config.panel.categories.map(cat => (
                                <button
                                  key={cat.id}
                                  onClick={() => {
                                    setConfig(prev => ({
                                      ...prev,
                                      panel: {
                                        ...prev.panel,
                                        categories: prev.panel.categories.filter(c => c.id !== cat.id)
                                      }
                                    }));
                                    showToast(`Categoría "${cat.label}" eliminada.`);
                                    setShowDeleteCatSelectMenu(false);
                                  }}
                                  className="w-full flex items-center justify-between p-1.5 rounded hover:bg-[#da373c]/20 text-xs text-white text-left"
                                >
                                  <span>{cat.emoji} {cat.label}</span>
                                  <Trash2 className="w-3 h-3 text-[#da373c]" />
                                </button>
                              ))}
                            </div>
                          </div>
                        )}
                      </div>
                    )}

                    {/* PUBLISHED TICKET PANEL (User-facing in #crear-ticket) */}
                    {panelPublishedIn === currentChannelId && (
                      <div className="space-y-3 pt-4 border-t border-[#35373c]">
                        <div className="flex items-center gap-2 text-xs text-[#5865F2] font-bold uppercase tracking-wider">
                          <Ticket className="w-4 h-4" />
                          <span>Panel de Soporte Publicado (Vista de los Usuarios)</span>
                        </div>

                        {/* Real Discord Public Embed */}
                        <div
                          className="max-w-xl rounded-md bg-[#2b2d31] p-4 text-sm border-l-4 shadow-xl space-y-3"
                          style={{ borderLeftColor: config.panel.color || '#5865F2' }}
                        >
                          <h3 className="text-lg font-bold text-white">
                            {config.panel.title}
                          </h3>

                          <p className="text-sm text-[#dbdee1] whitespace-pre-line leading-relaxed">
                            {config.panel.description}
                          </p>

                          {config.panel.imageUrl && (
                            <div className="overflow-hidden rounded border border-white/5">
                              <img
                                src={config.panel.imageUrl}
                                alt="Ticket Banner"
                                className="w-full h-44 object-cover"
                              />
                            </div>
                          )}

                          <div className="pt-2 border-t border-[#35373c] flex items-center justify-between text-[11px] text-[#949ba4]">
                            <span>Servidor de Soporte • Sistema Automatizado</span>
                            <span>Hoy a las 14:00</span>
                          </div>

                          {/* DISCORD STRING SELECT MENU */}
                          <div className="pt-2">
                            <label className="text-[11px] font-bold text-[#b5bac1] uppercase block mb-1">
                              StringSelectMenuBuilder:
                            </label>
                            <select
                              defaultValue=""
                              onChange={e => {
                                if (e.target.value) {
                                  handleOpenTicket(e.target.value);
                                  e.target.value = '';
                                }
                              }}
                              className="w-full bg-[#1e1f22] border border-[#3f4147] hover:border-[#5865F2] text-white rounded p-3 text-sm focus:outline-none transition cursor-pointer shadow-inner"
                            >
                              <option value="" disabled>
                                {config.panel.placeholder || 'Selecciona una categoría para abrir un ticket...'}
                              </option>
                              {config.panel.categories.map(cat => (
                                <option key={cat.id} value={cat.id}>
                                  {cat.emoji} {cat.label} — {cat.description}
                                </option>
                              ))}
                            </select>
                          </div>
                        </div>
                      </div>
                    )}
                  </>
                )}
              </div>

              {/* Chat Input Footer */}
              <div className="p-4 bg-[#313338] border-t border-[#202225] shrink-0">
                <div className="bg-[#383a40] rounded-lg px-4 py-2.5 flex items-center justify-between text-sm text-[#949ba4]">
                  <span className="italic">
                    Enviar mensaje en #{currentTicket ? currentTicket.channelName : currentChannel?.name || 'canal'}...
                  </span>
                  <div className="flex items-center gap-2">
                    <span className="text-[10px] bg-[#5865F2]/20 text-[#5865F2] px-2 py-0.5 rounded font-mono">
                      discord.js v14
                    </span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* ================= TAB 2: CODE EXPLORER ================= */}
        {activeTab === 'code' && (
          <div className="flex-1 flex overflow-hidden bg-[#1e1f22]">
            {/* File List Sidebar */}
            <div className="w-72 bg-[#25272b] border-r border-[#18191c] flex flex-col shrink-0">
              <div className="p-3 border-b border-[#18191c] flex items-center justify-between">
                <span className="text-xs font-bold text-[#b5bac1] uppercase tracking-wider flex items-center gap-1.5">
                  <Code2 className="w-4 h-4 text-[#5865F2]" />
                  Archivos del Bot
                </span>
                <span className="text-[11px] bg-[#5865F2]/20 text-[#5865F2] px-1.5 py-0.5 rounded font-mono">
                  {BOT_FILES.length} archivos
                </span>
              </div>

              <div className="flex-1 overflow-y-auto p-2 space-y-1">
                {BOT_FILES.map(file => (
                  <button
                    key={file.path}
                    onClick={() => setSelectedFile(file)}
                    className={`w-full text-left p-2.5 rounded text-xs transition flex flex-col gap-0.5 ${
                      selectedFile.path === file.path
                        ? 'bg-[#5865F2] text-white font-medium shadow'
                        : 'text-[#949ba4] hover:bg-[#313338] hover:text-white'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <span className="font-mono font-semibold">{file.name}</span>
                      <span className="text-[10px] opacity-70 uppercase">{file.language}</span>
                    </div>
                    <span className={`text-[10px] truncate ${selectedFile.path === file.path ? 'text-white/80' : 'text-[#80848e]'}`}>
                      {file.path}
                    </span>
                  </button>
                ))}
              </div>

              <div className="p-3 border-t border-[#18191c] bg-[#1f2023] space-y-2">
                <button
                  onClick={handleDownloadZip}
                  disabled={isDownloadingZip}
                  className="w-full bg-[#23a55a] hover:bg-[#1a8346] text-white py-2 rounded text-xs font-semibold flex items-center justify-center gap-1.5 transition shadow"
                >
                  <Download className="w-4 h-4" />
                  {isDownloadingZip ? 'Comprimiendo...' : 'Descargar Proyecto (.ZIP)'}
                </button>
                <button
                  onClick={() => {
                    const allCode = BOT_FILES.map(
                      f => `// ================= ${f.path} =================\n${f.content}\n`
                    ).join('\n');
                    navigator.clipboard.writeText(allCode);
                    setCopiedAll(true);
                    showToast('¡Todos los archivos copiados!');
                    setTimeout(() => setCopiedAll(false), 2000);
                  }}
                  className="w-full bg-[#35373c] hover:bg-[#404249] text-white py-2 rounded text-xs font-semibold flex items-center justify-center gap-1.5 transition"
                >
                  {copiedAll ? <Check className="w-4 h-4 text-[#57F287]" /> : <Copy className="w-4 h-4" />}
                  {copiedAll ? '¡Copiado!' : 'Copiar Proyecto Completo'}
                </button>
              </div>
            </div>

            {/* Code Content View */}
            <div className="flex-1 flex flex-col bg-[#111214] overflow-hidden">
              {/* File Header */}
              <div className="h-12 border-b border-[#2b2d31] px-4 flex items-center justify-between bg-[#18191c] shrink-0">
                <div className="flex items-center gap-2">
                  <span className="text-xs font-mono font-bold text-white">{selectedFile.path}</span>
                  <span className="text-xs text-[#949ba4] hidden sm:inline">• {selectedFile.description}</span>
                </div>
                <button
                  onClick={() => handleCopyCode(selectedFile.content)}
                  className="flex items-center gap-1.5 bg-[#5865F2] hover:bg-[#4752c4] text-white px-3 py-1.5 rounded text-xs font-semibold transition shadow"
                >
                  {copiedFile ? <Check className="w-3.5 h-3.5 text-[#57F287]" /> : <Copy className="w-3.5 h-3.5" />}
                  {copiedFile ? 'Copiado' : 'Copiar Archivo'}
                </button>
              </div>

              {/* Code Pre/Code block */}
              <div className="flex-1 overflow-auto p-4 font-mono text-xs text-[#dbdee1] leading-relaxed">
                <pre className="whitespace-pre">
                  <code>{selectedFile.content}</code>
                </pre>
              </div>
            </div>
          </div>
        )}

        {/* ================= TAB 3: STEP-BY-STEP DEPLOY GUIDE ================= */}
        {activeTab === 'guide' && (
          <div className="flex-1 overflow-y-auto bg-[#313338] p-6 lg:p-10 space-y-8 max-w-5xl mx-auto">
            <div>
              <h2 className="text-2xl font-bold text-white flex items-center gap-2">
                <BookOpen className="w-7 h-7 text-[#5865F2]" />
                Guía Completa de Instalación y Despliegue
              </h2>
              <p className="text-sm text-[#949ba4] mt-1">
                Sigue estos 5 sencillos pasos para configurar y poner en marcha tu bot de soporte en Discord.
              </p>
            </div>

            {/* GITHUB ERROR TROUBLESHOOTING BOX */}
            <div className="bg-[#5865F2]/10 border border-[#5865F2]/40 rounded-xl p-4 space-y-3">
              <div className="flex items-center gap-2 text-sm font-bold text-white">
                <AlertCircle className="w-5 h-5 text-[#5865F2] shrink-0" />
                <span>¿Te da error al intentar mandar el proyecto a tu nuevo GitHub?</span>
              </div>
              <p className="text-xs text-[#dbdee1] leading-relaxed">
                Este error suele ocurrir porque el navegador o Google AI Studio mantiene en caché la sesión de tu cuenta anterior de GitHub y no tiene permisos para crear repositorios en la cuenta nueva.
              </p>
              <div className="bg-[#1e1f22] p-3 rounded-lg border border-white/5 space-y-2 text-xs">
                <div className="font-semibold text-[#57F287] flex items-center gap-1.5">
                  <CheckCircle2 className="w-4 h-4" />
                  <span>Solución Rápida y 100% Segura (Sin fallos de cuenta):</span>
                </div>
                <ol className="list-decimal list-inside space-y-1 text-[#dbdee1] text-[11px]">
                  <li>
                    Haz clic en el botón verde superior <strong>«Descargar ZIP»</strong>.
                  </li>
                  <li>
                    En tu nuevo GitHub, ve a <a href="https://github.com/new" target="_blank" rel="noopener noreferrer" className="text-[#5865F2] hover:underline font-mono">github.com/new</a> y crea un nuevo repositorio (ej: <code>bot-tickets-discord</code>).
                  </li>
                  <li>
                    Descomprime el ZIP en tu PC y en la página de tu nuevo repositorio en GitHub haz clic en <strong>«uploading an existing file»</strong>, arrastra los archivos y pulsa <strong>«Commit changes»</strong>.
                  </li>
                  <li>
                    ¡Listo! Luego vas a Railway, conectas ese repositorio y agregas tus variables.
                  </li>
                </ol>
              </div>
            </div>

            <div className="grid gap-6">
              {/* Step 1: Discord Developer Portal */}
              <div className="bg-[#2b2d31] p-5 rounded-xl border border-[#3f4147] space-y-3 shadow-md">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2.5">
                    <span className="w-7 h-7 rounded-full bg-[#5865F2] text-white flex items-center justify-center font-bold text-xs">
                      1
                    </span>
                    <h3 className="text-base font-bold text-white">
                      Crear Aplicación & Bot en Discord Developer Portal
                    </h3>
                  </div>
                  <a
                    href="https://discord.com/developers/applications"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-xs text-[#5865F2] hover:underline flex items-center gap-1"
                  >
                    Discord Developer Portal <ExternalLink className="w-3.5 h-3.5" />
                  </a>
                </div>
                <p className="text-xs text-[#dbdee1] leading-relaxed">
                  1. Haz clic en <strong>"New Application"</strong> y asigna un nombre a tu bot (ej. <code>Soporte Tickets Bot</code>).
                  <br />
                  2. Entra a la pestaña <strong>"Bot"</strong> en el menú lateral y pulsa <strong>"Reset Token"</strong> para obtener tu <code>DISCORD_TOKEN</code>.
                  <br />
                  3. En la sección <strong>"Privileged Gateway Intents"</strong>, activa:
                </p>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
                  <div className="bg-[#1e1f22] p-2.5 rounded border border-[#57F287]/30 flex items-center gap-2 text-white">
                    <CheckCircle2 className="w-4 h-4 text-[#57F287] shrink-0" />
                    <span>Server Members Intent (Intento de Miembros)</span>
                  </div>
                  <div className="bg-[#1e1f22] p-2.5 rounded border border-[#57F287]/30 flex items-center gap-2 text-white">
                    <CheckCircle2 className="w-4 h-4 text-[#57F287] shrink-0" />
                    <span>Message Content Intent (Contenido de Mensajes)</span>
                  </div>
                </div>
                <p className="text-xs text-[#dbdee1]">
                  4. En la pestaña <strong>"General Information"</strong>, copia tu <strong>Application ID</strong> (es tu <code>CLIENT_ID</code>).
                </p>
              </div>

              {/* Step 2: Bot Invitation Link */}
              <div className="bg-[#2b2d31] p-5 rounded-xl border border-[#3f4147] space-y-3 shadow-md">
                <div className="flex items-center gap-2.5">
                  <span className="w-7 h-7 rounded-full bg-[#5865F2] text-white flex items-center justify-center font-bold text-xs">
                    2
                  </span>
                  <h3 className="text-base font-bold text-white">
                    Generar Enlace de Invitación con Permisos
                  </h3>
                </div>
                <p className="text-xs text-[#dbdee1] leading-relaxed">
                  1. Ve a <strong>OAuth2 → URL Generator</strong>.
                  <br />
                  2. En <strong>Scopes</strong>, marca: <code>bot</code> y <code>applications.commands</code>.
                  <br />
                  3. En <strong>Bot Permissions</strong>, marca <code>Administrator</code> (o específicamente: <em>Manage Channels, Manage Roles, View Channels, Send Messages, Embed Links, Attach Files, Read Message History</em>).
                  <br />
                  4. Abre el enlace generado e invita al bot a tu servidor de Discord.
                </p>
              </div>

              {/* Step 3: Configure .env */}
              <div className="bg-[#2b2d31] p-5 rounded-xl border border-[#3f4147] space-y-3 shadow-md">
                <div className="flex items-center gap-2.5">
                  <span className="w-7 h-7 rounded-full bg-[#5865F2] text-white flex items-center justify-center font-bold text-xs">
                    3
                  </span>
                  <h3 className="text-base font-bold text-white">
                    ¿Dónde poner el Token? (Railway vs Local)
                  </h3>
                </div>
                
                <div className="bg-[#da373c]/10 border border-[#da373c]/30 p-3 rounded-lg text-xs text-[#ff7b72] font-semibold flex items-center gap-2">
                  <AlertCircle className="w-4 h-4 shrink-0" />
                  <span>
                    ¡IMPORTANTE! NUNCA escribas tu token real dentro de los archivos de código (.js) ni lo subas a GitHub.
                  </span>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-3 pt-1">
                  {/* Option 1: Railway */}
                  <div className="bg-[#1e1f22] p-3.5 rounded-lg border border-[#5865F2]/40 space-y-2">
                    <div className="flex items-center gap-2 text-xs font-bold text-white">
                      <span className="px-1.5 py-0.5 rounded bg-[#5865F2] text-white text-[10px]">RECOMENDADO</span>
                      <span>Si lo subes a Railway ☁️</span>
                    </div>
                    <p className="text-[11px] text-[#dbdee1] leading-relaxed">
                      1. Sube tu código tal como está a GitHub.
                      <br />
                      2. En Railway, entra a tu proyecto y pulsa en la pestaña <strong>"Variables"</strong>.
                      <br />
                      3. Agrega con <em>"New Variable"</em>:
                    </p>
                    <div className="bg-[#111214] p-2 rounded font-mono text-[11px] text-[#57F287] space-y-0.5">
                      <div>DISCORD_TOKEN = tu_token_aqui</div>
                      <div>CLIENT_ID = tu_client_id_aqui</div>
                      <div>GUILD_ID = id_de_tu_servidor</div>
                    </div>
                    <p className="text-[10px] text-[#949ba4]">
                      Railway iniciará el bot 24/7 y registrará los comandos con <code className="text-white">npm start</code>.
                    </p>
                  </div>

                  {/* Option 2: Local */}
                  <div className="bg-[#1e1f22] p-3.5 rounded-lg border border-[#35373c] space-y-2">
                    <div className="text-xs font-bold text-white">
                      Si lo corres en tu PC (Local) 💻
                    </div>
                    <p className="text-[11px] text-[#dbdee1] leading-relaxed">
                      Copia el archivo <code>.env.example</code> y renómbralo a <code>.env</code> en la carpeta raíz:
                    </p>
                    <div className="bg-[#111214] p-2 rounded font-mono text-[11px] text-[#57F287] space-y-0.5">
                      <div>DISCORD_TOKEN="tu_token"</div>
                      <div>CLIENT_ID="tu_client_id"</div>
                      <div>GUILD_ID="tu_guild_id"</div>
                    </div>
                    <p className="text-[10px] text-[#949ba4]">
                      El archivo <code>.env</code> está protegido en <code>.gitignore</code> para que nunca se suba a la web.
                    </p>
                  </div>
                </div>
              </div>

              {/* Step 4: Deploy Slash Commands */}
              <div className="bg-[#2b2d31] p-5 rounded-xl border border-[#3f4147] space-y-3 shadow-md">
                <div className="flex items-center gap-2.5">
                  <span className="w-7 h-7 rounded-full bg-[#5865F2] text-white flex items-center justify-center font-bold text-xs">
                    4
                  </span>
                  <h3 className="text-base font-bold text-white">
                    Registrar los Comandos Slash (/set y /config)
                  </h3>
                </div>
                <p className="text-xs text-[#dbdee1]">
                  Ejecuta el script de registro para que Discord registre los comandos en la API de Discord:
                </p>
                <div className="bg-[#111214] p-3 rounded font-mono text-xs text-[#dbdee1] flex items-center justify-between">
                  <code>npm run deploy:commands</code>
                  <button
                    onClick={() => {
                      navigator.clipboard.writeText('npm run deploy:commands');
                      showToast('Comando copiado');
                    }}
                    className="text-[#949ba4] hover:text-white"
                  >
                    <Copy className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>

              {/* Step 5: Start the Bot */}
              <div className="bg-[#2b2d31] p-5 rounded-xl border border-[#3f4147] space-y-3 shadow-md">
                <div className="flex items-center gap-2.5">
                  <span className="w-7 h-7 rounded-full bg-[#23a55a] text-white flex items-center justify-center font-bold text-xs">
                    5
                  </span>
                  <h3 className="text-base font-bold text-white">
                    Iniciar el Bot de Soporte
                  </h3>
                </div>
                <p className="text-xs text-[#dbdee1]">
                  Inicia el cliente de Discord:
                </p>
                <div className="bg-[#111214] p-3 rounded font-mono text-xs text-[#dbdee1] flex items-center justify-between">
                  <code>npm run bot</code>
                  <button
                    onClick={() => {
                      navigator.clipboard.writeText('npm run bot');
                      showToast('Comando copiado');
                    }}
                    className="text-[#949ba4] hover:text-white"
                  >
                    <Copy className="w-3.5 h-3.5" />
                  </button>
                </div>
                <div className="text-xs text-[#57F287] bg-[#57F287]/10 p-3 rounded mt-2">
                  ¡Listo! En tu servidor de Discord ya puedes ejecutar <code>/set category-tickets</code>, <code>/set ticket-channel</code>, <code>/set staff-roles</code> y <code>/config ticket-panel</code>.
                </div>
              </div>
            </div>
          </div>
        )}

        {/* ================= TAB 4: JSON STORAGE STATE ================= */}
        {activeTab === 'state' && (
          <div className="flex-1 overflow-y-auto bg-[#1e1f22] p-6 lg:p-8 space-y-6 max-w-5xl mx-auto">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-xl font-bold text-white flex items-center gap-2">
                  <Terminal className="w-5 h-5 text-[#5865F2]" />
                  Estado de Persistencia (bot/data/guilds.json)
                </h2>
                <p className="text-xs text-[#949ba4] mt-0.5">
                  Estructura persistente en disco que se mantiene automáticamente al reiniciar el bot.
                </p>
              </div>

              <button
                onClick={() => {
                  setConfig(prev => ({
                    ...prev,
                    categoryId: 'cat_tickets_target',
                    panelChannelId: 'ch_tickets',
                    staffRoleIds: ['role_support', 'role_admin'],
                    ticketCounter: 0,
                    activeTickets: {}
                  }));
                  showToast('Configuración reiniciada');
                }}
                className="flex items-center gap-1.5 bg-[#35373c] hover:bg-[#404249] text-white px-3 py-1.5 rounded text-xs font-semibold transition"
              >
                <RefreshCw className="w-3.5 h-3.5" />
                Restaurar Valores por Defecto
              </button>
            </div>

            {/* Checklist of readiness */}
            <div className="grid grid-cols-1 sm:grid-cols-4 gap-3 text-xs">
              <div className={`p-3 rounded-lg border ${config.categoryId ? 'bg-[#57F287]/10 border-[#57F287]/30 text-white' : 'bg-[#da373c]/10 border-[#da373c]/30 text-[#da373c]'}`}>
                <div className="font-bold flex items-center gap-1.5 mb-1">
                  {config.categoryId ? <CheckCircle2 className="w-4 h-4 text-[#57F287]" /> : <AlertCircle className="w-4 h-4" />}
                  1. Categoría Tickets
                </div>
                <div className="text-[11px] opacity-80">
                  {config.categoryId ? 'Configurada' : 'Falta /set category-tickets'}
                </div>
              </div>

              <div className={`p-3 rounded-lg border ${config.panelChannelId ? 'bg-[#57F287]/10 border-[#57F287]/30 text-white' : 'bg-[#da373c]/10 border-[#da373c]/30 text-[#da373c]'}`}>
                <div className="font-bold flex items-center gap-1.5 mb-1">
                  {config.panelChannelId ? <CheckCircle2 className="w-4 h-4 text-[#57F287]" /> : <AlertCircle className="w-4 h-4" />}
                  2. Canal del Panel
                </div>
                <div className="text-[11px] opacity-80">
                  {config.panelChannelId ? 'Configurado' : 'Falta /set ticket-channel'}
                </div>
              </div>

              <div className={`p-3 rounded-lg border ${config.staffRoleIds.length > 0 ? 'bg-[#57F287]/10 border-[#57F287]/30 text-white' : 'bg-[#da373c]/10 border-[#da373c]/30 text-[#da373c]'}`}>
                <div className="font-bold flex items-center gap-1.5 mb-1">
                  {config.staffRoleIds.length > 0 ? <CheckCircle2 className="w-4 h-4 text-[#57F287]" /> : <AlertCircle className="w-4 h-4" />}
                  3. Roles de Soporte
                </div>
                <div className="text-[11px] opacity-80">
                  {config.staffRoleIds.length} roles asignados
                </div>
              </div>

              <div className={`p-3 rounded-lg border ${panelPublishedIn ? 'bg-[#57F287]/10 border-[#57F287]/30 text-white' : 'bg-[#da373c]/10 border-[#da373c]/30 text-[#da373c]'}`}>
                <div className="font-bold flex items-center gap-1.5 mb-1">
                  {panelPublishedIn ? <CheckCircle2 className="w-4 h-4 text-[#57F287]" /> : <AlertCircle className="w-4 h-4" />}
                  4. Panel Publicado
                </div>
                <div className="text-[11px] opacity-80">
                  {panelPublishedIn ? 'Publicado y activo' : 'Pendiente publicar'}
                </div>
              </div>
            </div>

            {/* Live JSON Inspector */}
            <div className="bg-[#111214] p-4 rounded-lg border border-[#2b2d31] font-mono text-xs text-[#57F287] overflow-x-auto shadow-inner">
              <pre>{JSON.stringify({ 'guild_123456789': config }, null, 2)}</pre>
            </div>
          </div>
        )}
      </div>

      {/* ================= AUTHENTIC DISCORD MODAL POPUP ================= */}
      {activeModal !== 'none' && (
        <div className="fixed inset-0 z-50 bg-black/70 flex items-center justify-center p-4">
          <div className="w-full max-w-md bg-[#313338] border border-[#3f4147] rounded-lg shadow-2xl overflow-hidden flex flex-col animate-in fade-in zoom-in-95 duration-150">
            {/* Modal Header */}
            <div className="p-4 border-b border-[#202225] flex items-center justify-between bg-[#2b2d31]">
              <h3 className="font-bold text-white text-base">
                {activeModal === 'modal_text' && 'Editar Título y Mensaje del Panel'}
                {activeModal === 'modal_image' && 'Configurar Imagen / Banner del Panel'}
                {activeModal === 'modal_color' && 'Personalizar Color del Embed'}
                {activeModal === 'modal_add_cat' && 'Añadir Nueva Categoría de Ticket'}
              </h3>
              <button
                onClick={() => setActiveModal('none')}
                className="text-[#949ba4] hover:text-white"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Modal Body */}
            <div className="p-4 space-y-4">
              {/* Modal 1: Title & Description */}
              {activeModal === 'modal_text' && (
                <>
                  <div>
                    <label className="text-[11px] font-bold text-[#b5bac1] uppercase block mb-1">
                      Título del Panel (TextInputStyle.Short)
                    </label>
                    <input
                      type="text"
                      value={modalTitle}
                      onChange={e => setModalTitle(e.target.value)}
                      maxLength={100}
                      className="w-full bg-[#1e1f22] border border-[#35373c] text-white rounded p-2 text-xs focus:outline-none focus:border-[#5865F2]"
                    />
                  </div>
                  <div>
                    <label className="text-[11px] font-bold text-[#b5bac1] uppercase block mb-1">
                      Mensaje / Descripción (TextInputStyle.Paragraph)
                    </label>
                    <textarea
                      rows={5}
                      value={modalDescription}
                      onChange={e => setModalDescription(e.target.value)}
                      maxLength={1500}
                      className="w-full bg-[#1e1f22] border border-[#35373c] text-white rounded p-2 text-xs focus:outline-none focus:border-[#5865F2]"
                    />
                  </div>
                </>
              )}

              {/* Modal 2: Image URL */}
              {activeModal === 'modal_image' && (
                <div>
                  <label className="text-[11px] font-bold text-[#b5bac1] uppercase block mb-1">
                    URL de la Imagen o Banner (escribe "quitar" para borrar)
                  </label>
                  <input
                    type="text"
                    value={modalImageUrl}
                    onChange={e => setModalImageUrl(e.target.value)}
                    placeholder="https://ejemplo.com/banner.png"
                    className="w-full bg-[#1e1f22] border border-[#35373c] text-white rounded p-2 text-xs focus:outline-none focus:border-[#5865F2]"
                  />
                  <p className="text-[11px] text-[#949ba4] mt-1.5">
                    Se mostrará como banner principal en el embed publicado.
                  </p>
                </div>
              )}

              {/* Modal 3: Color Embed */}
              {activeModal === 'modal_color' && (
                <div className="space-y-3">
                  <div>
                    <label className="text-[11px] font-bold text-[#b5bac1] uppercase block mb-1">
                      Código de Color Hex (#5865F2, #57F287, etc.)
                    </label>
                    <div className="flex items-center gap-2">
                      <input
                        type="color"
                        value={modalColor.startsWith('#') ? modalColor : `#${modalColor}`}
                        onChange={e => setModalColor(e.target.value)}
                        className="w-9 h-9 rounded cursor-pointer bg-transparent border-0"
                      />
                      <input
                        type="text"
                        value={modalColor}
                        onChange={e => setModalColor(e.target.value)}
                        maxLength={7}
                        className="flex-1 bg-[#1e1f22] border border-[#35373c] text-white rounded p-2 text-xs font-mono uppercase focus:outline-none focus:border-[#5865F2]"
                      />
                    </div>
                  </div>
                </div>
              )}

              {/* Modal 4: Add Category */}
              {activeModal === 'modal_add_cat' && (
                <>
                  <div>
                    <label className="text-[11px] font-bold text-[#b5bac1] uppercase block mb-1">
                      Nombre de la Categoría
                    </label>
                    <input
                      type="text"
                      value={modalCatLabel}
                      onChange={e => setModalCatLabel(e.target.value)}
                      placeholder="Ej: Reportes de Jugadores"
                      maxLength={50}
                      className="w-full bg-[#1e1f22] border border-[#35373c] text-white rounded p-2 text-xs focus:outline-none focus:border-[#5865F2]"
                    />
                  </div>
                  <div className="grid grid-cols-3 gap-2">
                    <div className="col-span-1">
                      <label className="text-[11px] font-bold text-[#b5bac1] uppercase block mb-1">
                        Emoji
                      </label>
                      <input
                        type="text"
                        value={modalCatEmoji}
                        onChange={e => setModalCatEmoji(e.target.value)}
                        placeholder="🛡️"
                        maxLength={4}
                        className="w-full bg-[#1e1f22] border border-[#35373c] text-white rounded p-2 text-xs text-center focus:outline-none focus:border-[#5865F2]"
                      />
                    </div>
                    <div className="col-span-2">
                      <label className="text-[11px] font-bold text-[#b5bac1] uppercase block mb-1">
                        Descripción Breve
                      </label>
                      <input
                        type="text"
                        value={modalCatDesc}
                        onChange={e => setModalCatDesc(e.target.value)}
                        placeholder="Ej: Denuncias y apelaciones"
                        maxLength={80}
                        className="w-full bg-[#1e1f22] border border-[#35373c] text-white rounded p-2 text-xs focus:outline-none focus:border-[#5865F2]"
                      />
                    </div>
                  </div>
                </>
              )}
            </div>

            {/* Modal Footer */}
            <div className="p-3 bg-[#2b2d31] border-t border-[#202225] flex items-center justify-end gap-2">
              <button
                onClick={() => setActiveModal('none')}
                className="px-3 py-1.5 rounded text-xs text-[#949ba4] hover:text-white hover:underline font-semibold"
              >
                Cancelar
              </button>
              <button
                onClick={() => {
                  if (activeModal === 'modal_text') {
                    setConfig(prev => ({
                      ...prev,
                      panel: {
                        ...prev.panel,
                        title: modalTitle,
                        description: modalDescription
                      }
                    }));
                    showToast('Textos del panel actualizados');
                  } else if (activeModal === 'modal_image') {
                    const cleaned = modalImageUrl.toLowerCase() === 'quitar' ? null : modalImageUrl;
                    setConfig(prev => ({
                      ...prev,
                      panel: { ...prev.panel, imageUrl: cleaned }
                    }));
                    showToast('Imagen del panel actualizada');
                  } else if (activeModal === 'modal_color') {
                    setConfig(prev => ({
                      ...prev,
                      panel: { ...prev.panel, color: modalColor }
                    }));
                    showToast('Color de embed actualizado');
                  } else if (activeModal === 'modal_add_cat') {
                    if (!modalCatLabel.trim()) return;
                    const newCat: TicketCategory = {
                      id: modalCatLabel.toLowerCase().replace(/[^a-z0-9_-]/g, '_').slice(0, 30),
                      label: modalCatLabel.trim(),
                      emoji: modalCatEmoji.trim() || '🎫',
                      description: modalCatDesc.trim() || 'Atención personalizada'
                    };
                    setConfig(prev => ({
                      ...prev,
                      panel: {
                        ...prev.panel,
                        categories: [...prev.panel.categories, newCat]
                      }
                    }));
                    showToast(`Categoría "${newCat.label}" añadida`);
                  }
                  setActiveModal('none');
                }}
                className="bg-[#5865F2] hover:bg-[#4752c4] text-white px-4 py-1.5 rounded text-xs font-semibold shadow transition"
              >
                Guardar Cambios
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
