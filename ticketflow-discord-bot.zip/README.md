# 🎫 Bot de Soporte de Tickets para Discord (discord.js v14)

Un bot de soporte para Discord profesional, moderno y completamente interactivo desarrollado con **Node.js** y **Discord.js v14**. Utiliza de forma nativa los componentes de Discord: **Channel Select Menus**, **Role Select Menus**, **String Select Menus**, **Modales** y **Botones**, permitiendo una configuración visual en tiempo real con persistencia automática de datos.

---

## 📋 Comandos Implementados

El bot incluye exactamente los 4 comandos solicitados:

1. **`/set category-tickets`**
   - Abre un menú desplegable de categorías (`ChannelSelectMenu` filtrado por `GuildCategory`).
   - Permite al administrador seleccionar la categoría del servidor de Discord donde se crearán todos los canales privados de tickets.

2. **`/set ticket-channel`**
   - Abre un menú desplegable de canales (`ChannelSelectMenu` filtrado por canales de texto y anuncios).
   - Permite al administrador seleccionar el canal donde se publicará el panel de tickets.

3. **`/config ticket-panel`**
   - Abre una interfaz de configuración visual interactiva mediante Embeds y Botones con acciones instantáneas:
     - **📝 Título y Mensaje:** Formulario modal para editar el título y la descripción completa del panel.
     - **🖼️ Imagen / Banner:** Formulario modal para añadir, cambiar o quitar (`quitar`) la imagen del panel.
     - **🎨 Color Embed:** Personalizar el color hexadecimal de la barra lateral del embed.
     - **➕ Añadir Categoría:** Formulario modal para definir el nombre, emoji (Unicode o personalizado), descripción breve e identificador de las opciones de tickets.
     - **🗑️ Eliminar Categoría:** Menú de selección interactivo para remover opciones del panel.
     - **🚀 Publicar Panel:** Envía el panel interactivo formateado con su menú desplegable de selección de tickets directamente al canal configurado en `/set ticket-channel`.
     - *Todos los cambios se guardan automáticamente en disco y se mantienen tras reiniciar el bot.*

4. **`/set staff-roles`**
   - Abre un selector múltiple de roles (`RoleSelectMenu`).
   - Permite seleccionar varios roles de soporte del servidor.
   - Cuando un usuario abre un ticket, el bot menciona automáticamente a todos los roles de soporte configurados para notificarlos.
   - Los roles seleccionados reciben permisos automáticos de lectura y escritura en los canales de tickets.

---

## 🔒 Funcionamiento del Panel y Creación de Tickets

1. **Publicación:** Al pulsar *Publicar Panel* desde `/config ticket-panel`, el bot envía el embed configurado con su título, descripción, imagen y menú desplegable (`StringSelectMenu`) con las categorías creadas.
2. **Creación del Ticket:** Cuando un usuario selecciona una categoría:
   - El bot valida que la categoría de tickets esté configurada.
   - Crea un canal de texto privado (`ticket-usuario-#`) dentro de la categoría configurada.
   - **Permisos aplicados:**
     - `@everyone`: Canal oculto (sin permiso de ver).
     - **Usuario que abrió el ticket:** Ver canal, enviar mensajes, subir archivos, ver historial.
     - **Roles de Staff configurados:** Ver canal, enviar mensajes, subir archivos, ver historial.
     - **Bot:** Administrar canal y enviar mensajes.
   - Envía un mensaje inicial mencionando a los roles de soporte configurados con los datos del ticket y un botón **"🔒 Cerrar Ticket"**.
   - Responde de forma privada y efímera al usuario con el enlace directo a su nuevo canal de soporte.
3. **Cierre de Ticket:** Al hacer clic en "🔒 Cerrar Ticket", el bot solicita confirmación. Tras confirmar, notifica el cierre y elimina el canal automáticamente en 5 segundos.

---

## 🚀 Requisitos e Instalación

### 1. Requisitos Previos
- **Node.js v18.0.0 o superior** ([Descargar Node.js](https://nodejs.org/))
- Una cuenta de Discord y acceso al [Discord Developer Portal](https://discord.com/developers/applications).

### 2. Crear la Aplicación en Discord Developer Portal
1. Ve a [Discord Developer Portal](https://discord.com/developers/applications) y pulsa **"New Application"**.
2. Dale un nombre a tu aplicación (ej: `Soporte Tickets Bot`).
3. Ve a la pestaña **"Bot"** en el menú izquierdo:
   - Haz clic en **"Add Bot"** o **"Reset Token"** para copiar tu **Token del Bot**. (⚠️ *Nunca compartas este token*).
   - En la sección **"Privileged Gateway Intents"**, activa:
     - ✅ **Server Members Intent**
     - ✅ **Message Content Intent**
   - Guarda los cambios (**Save Changes**).
4. Ve a la pestaña **"General Information"** y copia el **Application ID** (este es tu `CLIENT_ID`).
5. Ve a **"OAuth2" -> "URL Generator"**:
   - En *Scopes*, marca: `bot` y `applications.commands`.
   - En *Bot Permissions*, marca: `Administrator` (o `Manage Channels`, `Manage Roles`, `View Channels`, `Send Messages`, `Embed Links`, `Attach Files`, `Read Message History`).
   - Copia la URL generada al final y ábrela en tu navegador para invitar al bot a tu servidor de Discord.

---

## ⚙️ Configuración del Token y Variables de Entorno

> ⚠️ **REGLA DE ORO DE SEGURIDAD:**  
> **NUNCA** pegues tu token directamente dentro de los archivos de código (`.js`) ni subas tu token a GitHub. Si lo haces, Discord anula el token inmediatamente por seguridad.

### Opción A: Despliegue en la Nube (Railway) ☁️
Si vas a alojar el bot en **Railway**:
1. Sube tu código a GitHub **sin incluir el token** en ningún archivo (el archivo `.gitignore` ya protege `.env`).
2. En Railway, crea un nuevo proyecto desde tu repositorio de GitHub.
3. Entra a tu proyecto en Railway y haz clic en la pestaña **"Variables"** (Environment Variables).
4. Agrega estas variables haciendo clic en **"New Variable"**:
   - `DISCORD_TOKEN` = Pega tu token de Discord aquí.
   - `CLIENT_ID` = Pega tu Application ID de Discord.
   - `GUILD_ID` = (Opcional) El ID de tu servidor para probar comandos al instante.
5. Railway ejecutará automáticamente `npm start` (que registra los comandos slash y enciende el bot 24/7).

### Opción B: Ejecución en tu Computadora (Local) 💻
Si vas a correr el bot en tu PC:
1. Copia el archivo `.env.example` y renómbralo a `.env`:
   ```bash
   cp .env.example .env
   ```
2. Abre `.env` con un editor de texto y rellena tus credenciales:
   ```env
   DISCORD_TOKEN="TU_TOKEN_DE_DISCORD_AQUI"
   CLIENT_ID="TU_APPLICATION_ID_AQUI"
   GUILD_ID="123456789012345678"
   ```
   *(Este archivo `.env` nunca se sube a internet gracias a `.gitignore`)*.

---

## 📦 Instalación de Dependencias

Ejecuta el siguiente comando en la terminal dentro de la carpeta del proyecto:

```bash
npm install
```

---

## 🛠️ Despliegue de Comandos e Inicio del Bot

### Paso 1: Registrar los Comandos Slash
Antes de iniciar el bot por primera vez (o tras modificar comandos), ejecuta:

```bash
npm run deploy:commands
```

Verás una salida confirmando que los comandos `/set` y `/config` han sido registrados en la API de Discord.

### Paso 2: Iniciar el Bot
Ejecuta:

```bash
npm run bot
```

Verás en la consola:
```
===============================================
🤖 ¡Bot iniciado con éxito como Soporte Bot#1234!
🆔 Bot ID: 123456789012345678
🌐 Servidores conectados: 1
===============================================
```

---

## 📖 Guía de Uso en Discord

Una vez el bot esté conectado a tu servidor:

1. **Establecer categoría de tickets:**
   Ejecuta:
   ```
   /set category-tickets
   ```
   Selecciona en el menú desplegable la categoría deseada (ej: `📁 TICKETS`).

2. **Establecer canal del panel:**
   Ejecuta:
   ```
   /set ticket-channel
   ```
   Selecciona en el menú el canal donde los miembros verán el panel (ej: `#crear-ticket`).

3. **Asignar roles de soporte:**
   Ejecuta:
   ```
   /set staff-roles
   ```
   Selecciona uno o varios roles (ej: `@Soporte`, `@Moderador`, `@Administrador`).

4. **Personalizar y publicar el panel:**
   Ejecuta:
   ```
   /config ticket-panel
   ```
   - Usa los botones para cambiar el título, la descripción, el banner o añadir tus categorías personalizadas con emojis.
   - Pulsa el botón verde **"🚀 Publicar Panel de Tickets"**.
   - ¡Listo! El panel se enviará al canal configurado y los usuarios podrán empezar a abrir tickets.

---

## 📂 Estructura del Código

```
├── bot/
│   ├── commands/
│   │   ├── set.js             # Comandos /set category-tickets, ticket-channel, staff-roles
│   │   └── config.js          # Comando /config ticket-panel
│   ├── interactions/
│   │   ├── selectMenus.js     # Manejador de Select Menus (canales, roles, categorías, tickets)
│   │   ├── modals.js          # Manejador de formularios Modales (título, texto, imagen, etc.)
│   │   └── buttons.js         # Manejador de botones (configuración, cierre de tickets)
│   ├── utils/
│   │   └── embeds.js          # Creadores de Embeds y componentes Discord.js v14
│   ├── data/
│   │   └── guilds.json        # Base de datos persistente en formato JSON por servidor
│   ├── deploy-commands.js     # Script de registro de slash commands en REST API v10
│   ├── storage.js             # Módulo de persistencia seguro en disco
│   └── index.js               # Punto de entrada principal y cliente de Discord
├── .env.example               # Plantilla de variables de entorno
├── package.json               # Dependencias y scripts de ejecución
└── README.md                  # Documentación completa
```
